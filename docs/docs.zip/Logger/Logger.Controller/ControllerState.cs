namespace Logger.Controller
{
    public class ControllerState
    {
        internal ControllerState(string message, bool running, bool clearResults, bool isShortProcess)
        {
            this.message = message;
            this.running = running;
            this.clearResults = clearResults;
            this.isShortProcess = isShortProcess;
        }

        private string message;
        public string Message
        {
            get { return message; }
        }

        private bool running;
        public bool Running
        {
            get { return running; }
        }

        private bool clearResults;
        public bool ClearResults
        {
            get { return clearResults; }
        }

        private bool isShortProcess;
        public bool IsShortProcess
        {
            get { return isShortProcess; }
        }
    }
}
