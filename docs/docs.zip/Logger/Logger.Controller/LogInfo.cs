using System;
using System.Xml;
using System.Collections.Generic;
using System.Text;

namespace Logger.Controller
{
    public class LogInfo
    {
        private string info;
        public LogInfo(string info)
        {
            this.info = info;
            string[] items = info.Split('|');
            functionID = long.Parse(items[0]);
            className = items[1];
            functionName = items[2];
            isStatic = int.Parse(items[3]) > 0;
            returnType = items[4];
            int parameterCount = int.Parse(items[5]);
            ParseParameters(items, parameterCount);
            time = DateTime.FromBinary(long.Parse(items[parameterCount + 6]));
            threadID = int.Parse(items[parameterCount + 7]);

            BuildFormattedText();
        }

        private void ParseParameters(string[] items, int parameterCount)
        {
            if (parameterCount > 0)
            {
                for (int i = 0; i < parameterCount; i++)
                {
                    parameters.Add(items[i + 6]);
                }
            }
        }

        private void BuildFormattedText()
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendFormat("{0}.{1}", className, functionName);
            if (isStatic)
            {
                builder.Append("[static]");
            }

            builder.Append("(");
            for (int i = 0; i < parameters.Count; i++)
            {
                if (i > 0)
                {
                    builder.Append(", ");
                }
                builder.Append(parameters[i]);
            }
            builder.AppendFormat(") {0}", returnType);
            formattedText = builder.ToString();
        }

        private long functionID;
        public long FunctionID
        {
            get { return functionID; }
        }

        private string className;
        public string ClassName
        {
            get { return className; }
        }

        private string functionName;
        public string FunctionName
        {
            get { return functionName; }
        }

        private bool isStatic;
        public bool IsStatic
        {
            get { return isStatic; }
        }

        private string returnType;
        public string ReturnType
        {
            get { return returnType; }
        }

        private List<string> parameters = new List<string>();
        public string[] Parameters
        {
            get { return parameters.ToArray(); }
        }

        private DateTime time;
        public DateTime Time
        {
            get { return time; }
        }

        private int threadID;
        public int ThreadID
        {
            get { return threadID; }
        }

        private string formattedText;
        public string FormattedText
        {
            get { return formattedText; }
        }
        
        public override string ToString()
        {
            return formattedText;
            //return string.Format("{0} Time:{1:HH:mm:ss:ms} Thread:{2:0x0000}", function, time, threadID);
        }
    }
}
