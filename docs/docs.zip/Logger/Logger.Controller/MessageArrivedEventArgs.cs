using System;

namespace Logger.Controller
{
    public class MessageArrivedEventArgs : EventArgs
    {
        public MessageArrivedEventArgs(LogInfo logInfo)
        {
            this.logInfo = logInfo;
        }

        private LogInfo logInfo;
        public LogInfo LogInfo
        {
            get { return logInfo; }
        }
    }
}
