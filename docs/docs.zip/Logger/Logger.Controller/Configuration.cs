using Logger.Controller.Properties;

namespace Logger.Controller
{
    public sealed class Configuration
    {
        public static string ProfilerLogPath
        {
            get { return Settings.Default.ProfilerLogPath; }
            set
            {
                Settings.Default.ProfilerLogPath = value;
                Settings.Default.Save();
            }
        }

        public static int Port
        {
            get { return Settings.Default.Port; }
            set
            {
                Settings.Default.Port = value;
                Settings.Default.Save();
                ControllerManager.Instance.RegisterChannel();
            }
        }
    }
}
