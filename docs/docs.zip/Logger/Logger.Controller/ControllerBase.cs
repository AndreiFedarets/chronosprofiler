using System;
using System.IO;
using System.Collections.Generic;
using Logger.Controller.Properties;

namespace Logger.Controller
{
    public abstract class ControllerBase
    {
        internal static ControllerBase CreateController(string application)
        {
            if (application.StartsWith("http://", StringComparison.CurrentCultureIgnoreCase))
            {
                return new IISApplicationController(application);
            }
            else if (File.Exists(application))
            {
                return new WindowsApplicationController(application);
            }
            else
            {
                throw new Exception(string.Format(@"Unable to start application ""{0}"".", application));
            }
        }

        protected ControllerBase(string application)
        {
            this.application = application;
        }

        internal abstract void Start();
        internal abstract void Stop();

        private string application;
        public string Application
        {
            get { return application; }
        }

        protected Dictionary<string, string> GetEnvironmentVariables()
        {
            Dictionary<string, string> environmentVariables = new Dictionary<string, string>();
            environmentVariables.Add("Cor_Enable_Profiling", "0x1");
            environmentVariables.Add("COR_PROFILER", "{8782F5A0-E8B0-49af-B9D2-D0BE025D5D3E}");
            environmentVariables.Add("Logger_Profiler_Port", Configuration.Port.ToString());

            if (!string.IsNullOrEmpty(Settings.Default.ProfilerLogPath))
            {
                environmentVariables.Add("Logger_Profiler_Log", Settings.Default.ProfilerLogPath);
            }

            return environmentVariables;
        }
    }
}
