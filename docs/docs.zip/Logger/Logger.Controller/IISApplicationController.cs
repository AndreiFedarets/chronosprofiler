using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Microsoft.Win32;

namespace Logger.Controller
{
    public class IISApplicationController : ControllerBase
    {
        private string userSid;

        internal IISApplicationController(string application) : base(application)
        {
            accountName = "ASPNET";
            userSid = GetAccountSid();
        }

        private string accountName;
        internal string AccountName
        {
            get { return accountName; }
        }

        internal override void Start()
        {
            SetKeys();
            RestartIIS();
            Thread.Sleep(2000);

            ControllerManager.Instance.SetState(new ControllerState("Starting Site...", true, false, true));
            Process.Start(Application);
        }

        internal override void Stop()
        {
            DeleteKeys();
            RestartIIS();
        }

        private static void RestartIIS()
        {
            ControllerManager.Instance.SetState(new ControllerState("Restarting IIS...", true, false, true));
            ProcessStartInfo processStartInfo = new ProcessStartInfo("iisreset");
            processStartInfo.UseShellExecute = false;
            processStartInfo.CreateNoWindow = true;
            Process.Start(processStartInfo).WaitForExit(10000);
        }

        private string GetAccountSid()
        {
            uint sidSize = 256;
            byte[] sid = new byte[sidSize];
            StringBuilder referencedDomainName = new StringBuilder();
            uint referencedDomainNameSize = (uint)referencedDomainName.Capacity;
            int sidNameUse;

            HandleError(!NativeMethods.LookupAccountName(null, AccountName, sid, ref sidSize, referencedDomainName, ref referencedDomainNameSize, out sidNameUse));

            IntPtr ptrSid;
            HandleError(!NativeMethods.ConvertSidToStringSid(sid, out ptrSid));
            string result = Marshal.PtrToStringAuto(ptrSid);
            Marshal.FreeHGlobal(ptrSid);
            return result;
        }

        private void HandleError(bool errorOccurred)
        {
            if (errorOccurred)
            {
                throw new ApplicationException(string.Format("Unable to get SID for account name. Error Code : {0}", Marshal.GetLastWin32Error()));
            }
        }

        private string KeyName
        {
            get { return string.Format(@"{0}\Environment", userSid); }
        }

        private void SetKeys()
        {
            RegistryKey key = Registry.Users.OpenSubKey(KeyName, true);

            Dictionary<string, string> variables = GetEnvironmentVariables();
            foreach (string item in variables.Keys)
            {
                key.SetValue(item, variables[item]);
            }

            key.Close();
        }

        private void DeleteKeys()
        {
            RegistryKey key = Registry.Users.OpenSubKey(KeyName, true);

            foreach (string item in GetEnvironmentVariables().Keys)
            {
                key.DeleteValue(item, false);
            }

            key.Close();
        }
    }
}
