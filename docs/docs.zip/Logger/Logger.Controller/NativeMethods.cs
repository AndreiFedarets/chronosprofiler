using System;
using System.Text;
using System.Runtime.InteropServices;

namespace Logger.Controller
{
    public static class NativeMethods
    {
        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool LookupAccountName(string systemName, string accountName, [MarshalAs(UnmanagedType.LPArray)] byte[] sid, ref uint sidSize, StringBuilder referencedDomainName, ref uint referencedDomainNameSize, out int sidNameUse);

        [DllImport("advapi32", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool ConvertSidToStringSid([MarshalAs(UnmanagedType.LPArray)] byte[] pSID, out IntPtr ptrSid);
    }
}
