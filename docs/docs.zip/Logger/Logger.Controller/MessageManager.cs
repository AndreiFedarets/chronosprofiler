using System;
using System.IO;
using Logger.Common;

namespace Logger.Controller
{
    public class MessageManager : MarshalByRefObject, IMessageLogger
    {
        #region IMessageLogger Members

        public void LogMessage(string callInfo)
        {
            ControllerManager.Instance.ProcessMessage(new LogInfo(callInfo));
        }

        #endregion
    }
}
