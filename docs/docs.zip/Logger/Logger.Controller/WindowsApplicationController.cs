using System;
using System.Diagnostics;
using System.Collections.Generic;

namespace Logger.Controller
{
    public class WindowsApplicationController : ControllerBase
    {
        private Process process;

        internal WindowsApplicationController(string application) : base(application) { }

        internal override void Start()
        {
            ControllerManager.Instance.SetState(new ControllerState("Starting Application...", true, false, true));
            ProcessStartInfo startInfo = new ProcessStartInfo(Application);

            Dictionary<string, string> variables = GetEnvironmentVariables();
            foreach (string item in variables.Keys)
            {
                startInfo.EnvironmentVariables.Add(item, variables[item]);
            }

            startInfo.UseShellExecute = false;
            process = Process.Start(startInfo);
        }

        internal override void Stop()
        {
            if (!process.HasExited)
            {
                ControllerManager.Instance.SetState(new ControllerState("Stopping Application...", true, false, true));
                process.Kill();
            }
        }
    }
}
