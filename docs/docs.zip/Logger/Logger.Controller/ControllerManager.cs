using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Collections.Generic;

namespace Logger.Controller
{
    public sealed class ControllerManager
    {
        private static ControllerManager instance = new ControllerManager();
        public static ControllerManager Instance
        {
            get { return instance; }
        }

        private ControllerManager()
        {
            RegisterChannel();
            SetState(new ControllerState("Welcome to Logger!", false, true, false));
        }

        ~ControllerManager()
        {
            UnregisterChannel();
        }

        private TcpChannel channel;
        private TcpChannel Channel
        {
            get { return channel; }
        }

        private ControllerBase currentController;
        public ControllerBase CurrentController
        {
            get { return currentController; }
        }

        private ControllerState currentState;
        public ControllerState CurrentState
        {
            get { return currentState; }
        }

        public event EventHandler StateChanged;
        private void OnStateChanged(EventArgs e)
        {
            if (StateChanged != null)
            {
                StateChanged(this, e);
            }
        }

        public event EventHandler<MessageArrivedEventArgs> MessageArrived;
        private void OnMessageArrived(MessageArrivedEventArgs e)
        {
            if (MessageArrived != null)
            {
                MessageArrived.BeginInvoke(this, e, null, null);
            }
        }

        public void SetProfiller(string application)
        {
            if (CurrentController != null)
            {
                CurrentController.Stop();
            }

            currentController = ControllerBase.CreateController(application);
        }

        internal void SetState(ControllerState state)
        {
            currentState = state;
            OnStateChanged(EventArgs.Empty);
        }

        public void Start()
        {
            SetState(new ControllerState("Starting...", false, true, true));

            if (CurrentController != null)
            {
                CurrentController.Start();
            }

            SetState(new ControllerState("Logging...", true, false, false));
        }

        public void Stop()
        {
            SetState(new ControllerState("Stopping...", true, false, true));

            if (CurrentController != null)
            {
                CurrentController.Stop();
            }

            SetState(new ControllerState("Logging Stopped.", false, false, false));
        }

        internal void RegisterChannel()
        {
            UnregisterChannel();
            
            SetState(new ControllerState("Registering port: " + Configuration.Port, false, false, false));
            channel = new TcpChannel(Configuration.Port);
            ChannelServices.RegisterChannel(channel, false);
            RemotingConfiguration.RegisterWellKnownServiceType(typeof(MessageManager), "MessageManager.rem", WellKnownObjectMode.Singleton);
        }

        private void UnregisterChannel()
        {
            if (channel != null)
            {
                SetState(new ControllerState("Unregistering port: " + Configuration.Port, false, false, false));
                ChannelServices.UnregisterChannel(channel);
                channel = null;
            }
        }

        internal void ProcessMessage(LogInfo logInfo)
        {
            OnMessageArrived(new MessageArrivedEventArgs(logInfo));
        }
    }
}
