using System;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using Logger.Gui.Properties;
using Logger.Controller;

namespace Logger.Gui
{
    public partial class Main : Form
    {
        private bool autoScroll= true;

        public Main()
        {
            InitializeComponent();

            ControllerManager.Instance.StateChanged += new EventHandler(Instance_StateChanged);
            ControllerManager.Instance.MessageArrived += new EventHandler<MessageArrivedEventArgs>(Instance_MessageArrived);

            applicationTextBox.Text = Settings.Default.Application;
            ProcessCurrentState();
            SetAutoScroll();
        }

        private void Instance_MessageArrived(object sender, MessageArrivedEventArgs e)
        {
            Invoke(new ListItemAddDelegate(AppendItem), e.LogInfo);
        }

        private delegate void ListItemAddDelegate(LogInfo logInfo);
        private void AppendItem(LogInfo logInfo)
        {
            listBox.Items.Add(logInfo);

            if (autoScroll)
            {
                listBox.SelectedIndex = listBox.Items.Count - 1;
            }
        }

        private void Instance_StateChanged(object sender, EventArgs e)
        {
            ProcessCurrentState();
        }

        private void ProcessCurrentState()
        {
            if (IsDisposed)
            {
                return;
            }

            if (InvokeRequired)
            {
                Invoke(new EventHandler(Instance_StateChanged), this, EventArgs.Empty);
            }
            else
            {
                progressBar.Visible = ControllerManager.Instance.CurrentState.IsShortProcess;
                statusLabel.Text = ControllerManager.Instance.CurrentState.Message;
                statusStrip.Refresh();

                startButton.Enabled = !ControllerManager.Instance.CurrentState.Running;
                startToolStripMenuItem.Enabled = !ControllerManager.Instance.CurrentState.Running;
                optionsToolStripMenuItem.Enabled = !ControllerManager.Instance.CurrentState.Running;
                applicationTextBox.Enabled = !ControllerManager.Instance.CurrentState.Running;
                browseButton.Enabled = !ControllerManager.Instance.CurrentState.Running;

                stopButton.Enabled = ControllerManager.Instance.CurrentState.Running;
                stopToolStripMenuItem.Enabled = ControllerManager.Instance.CurrentState.Running;

                if (ControllerManager.Instance.CurrentState.ClearResults)
                {
                    listBox.Items.Clear();
                }
            }
        }

        private void SetAutoScroll()
        {
            autoScroll = !autoScroll;

            if (autoScroll)
            {
                autoScrollButton.Image = Resources.page_down;
                autoScrollToolStripMenuItem.Image = Resources.page_down;
                autoScrollToolStripMenuItem.Text = "Disable Auto Scroll";
            }
            else
            {
                autoScrollButton.Image = Resources.page_attachment;
                autoScrollToolStripMenuItem.Image = Resources.page_attachment;
                autoScrollToolStripMenuItem.Text = "Enable Auto Scroll";
            }
        }

        private void Start()
        {
            Settings.Default.Application = applicationTextBox.Text;
            Settings.Default.Save();

            ControllerManager.Instance.SetProfiller(applicationTextBox.Text);
            ThreadPool.QueueUserWorkItem(new WaitCallback(StartManager));
        }

        private void StartManager(object state)
        {
            ControllerManager.Instance.Start();
        }

        private void Stop()
        {
            ThreadPool.QueueUserWorkItem(new WaitCallback(StopManager));
        }

        private void StopManager(object state)
        {
            ControllerManager.Instance.Stop();
        }

        private void browseButton_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                applicationTextBox.Text = openFileDialog.FileName;
            }
        }

        private void Start_Handler(object sender, EventArgs e)
        {
            Start();
        }

        private void Stop_Handler(object sender, EventArgs e)
        {
            Stop();
        }

        private void AutoScroll_Handler(object sender, EventArgs e)
        {
            SetAutoScroll();
        }

        private void optionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Options().ShowDialog(this);
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new About().ShowDialog(this);
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            ControllerManager.Instance.Stop();
        }

        private void listBox_DoubleClick(object sender, EventArgs e)
        {
            LogInfo logInfo = listBox.SelectedItem as LogInfo;
            if (logInfo != null)
            {
                new LogDetailViewer(logInfo).Show(this);
            }
        }
    }
}