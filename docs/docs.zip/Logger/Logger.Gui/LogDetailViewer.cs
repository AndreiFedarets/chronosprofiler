using System;
using System.Windows.Forms;
using Logger.Controller;

namespace Logger.Gui
{
    public partial class LogDetailViewer : Form
    {
        public LogDetailViewer(LogInfo logInfo)
        {
            InitializeComponent();

            functionIDLabel.Text += logInfo.FunctionID.ToString();
            signatureLabel.Text += logInfo.FormattedText;
            timeLabel.Text += logInfo.Time.ToString("HH:mm:ss.ms");
            threadIDLabel.Text += logInfo.ThreadID.ToString();
        }
    }
}