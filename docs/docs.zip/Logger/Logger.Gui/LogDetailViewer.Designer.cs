namespace Logger.Gui
{
    partial class LogDetailViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.functionIDLabel = new System.Windows.Forms.Label();
            this.signatureLabel = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.threadIDLabel = new System.Windows.Forms.Label();
            this.timeLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.functionIDLabel);
            this.groupBox1.Controls.Add(this.signatureLabel);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(445, 65);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Signature";
            // 
            // functionIDLabel
            // 
            this.functionIDLabel.AutoSize = true;
            this.functionIDLabel.Location = new System.Drawing.Point(10, 16);
            this.functionIDLabel.Name = "functionIDLabel";
            this.functionIDLabel.Size = new System.Drawing.Size(71, 13);
            this.functionIDLabel.TabIndex = 1;
            this.functionIDLabel.Text = "Function ID:  ";
            // 
            // signatureLabel
            // 
            this.signatureLabel.Location = new System.Drawing.Point(10, 29);
            this.signatureLabel.Name = "signatureLabel";
            this.signatureLabel.Size = new System.Drawing.Size(429, 33);
            this.signatureLabel.TabIndex = 0;
            this.signatureLabel.Text = "Signature:  ";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.threadIDLabel);
            this.groupBox2.Controls.Add(this.timeLabel);
            this.groupBox2.Location = new System.Drawing.Point(13, 83);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(444, 48);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Extended Info";
            // 
            // threadIDLabel
            // 
            this.threadIDLabel.AutoSize = true;
            this.threadIDLabel.Location = new System.Drawing.Point(148, 20);
            this.threadIDLabel.Name = "threadIDLabel";
            this.threadIDLabel.Size = new System.Drawing.Size(64, 13);
            this.threadIDLabel.TabIndex = 1;
            this.threadIDLabel.Text = "Thread ID:  ";
            // 
            // timeLabel
            // 
            this.timeLabel.AutoSize = true;
            this.timeLabel.Location = new System.Drawing.Point(9, 20);
            this.timeLabel.Name = "timeLabel";
            this.timeLabel.Size = new System.Drawing.Size(39, 13);
            this.timeLabel.TabIndex = 0;
            this.timeLabel.Text = "Time:  ";
            // 
            // LogDetailViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(469, 143);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "LogDetailViewer";
            this.Text = "Detail";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label signatureLabel;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label functionIDLabel;
        private System.Windows.Forms.Label threadIDLabel;
        private System.Windows.Forms.Label timeLabel;
    }
}