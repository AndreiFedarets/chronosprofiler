namespace Logger.Gui
{
    partial class Options
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.logCheckBox = new System.Windows.Forms.CheckBox();
            this.profilerLogPathTextBox = new System.Windows.Forms.TextBox();
            this.profilerLogGroup = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.browseButton = new System.Windows.Forms.Button();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.portTextBox = new System.Windows.Forms.NumericUpDown();
            this.profilerLogGroup.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.portTextBox)).BeginInit();
            this.SuspendLayout();
            // 
            // logCheckBox
            // 
            this.logCheckBox.AutoSize = true;
            this.logCheckBox.Location = new System.Drawing.Point(6, 19);
            this.logCheckBox.Name = "logCheckBox";
            this.logCheckBox.Size = new System.Drawing.Size(70, 17);
            this.logCheckBox.TabIndex = 0;
            this.logCheckBox.Text = "Generate";
            this.logCheckBox.UseVisualStyleBackColor = true;
            this.logCheckBox.CheckedChanged += new System.EventHandler(this.logCheckBox_CheckedChanged);
            // 
            // profilerLogPathTextBox
            // 
            this.profilerLogPathTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.profilerLogPathTextBox.Location = new System.Drawing.Point(36, 40);
            this.profilerLogPathTextBox.Name = "profilerLogPathTextBox";
            this.profilerLogPathTextBox.Size = new System.Drawing.Size(249, 20);
            this.profilerLogPathTextBox.TabIndex = 2;
            // 
            // profilerLogGroup
            // 
            this.profilerLogGroup.Controls.Add(this.label1);
            this.profilerLogGroup.Controls.Add(this.browseButton);
            this.profilerLogGroup.Controls.Add(this.profilerLogPathTextBox);
            this.profilerLogGroup.Controls.Add(this.logCheckBox);
            this.profilerLogGroup.Location = new System.Drawing.Point(12, 12);
            this.profilerLogGroup.Name = "profilerLogGroup";
            this.profilerLogGroup.Size = new System.Drawing.Size(321, 71);
            this.profilerLogGroup.TabIndex = 3;
            this.profilerLogGroup.TabStop = false;
            this.profilerLogGroup.Text = "Profiler Log";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Path";
            // 
            // browseButton
            // 
            this.browseButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.browseButton.Location = new System.Drawing.Point(291, 38);
            this.browseButton.Name = "browseButton";
            this.browseButton.Size = new System.Drawing.Size(24, 23);
            this.browseButton.TabIndex = 3;
            this.browseButton.Text = "...";
            this.browseButton.UseVisualStyleBackColor = true;
            this.browseButton.Click += new System.EventHandler(this.browseButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.portTextBox);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(13, 89);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(320, 50);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Network";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Port";
            // 
            // portTextBox
            // 
            this.portTextBox.Location = new System.Drawing.Point(41, 14);
            this.portTextBox.Maximum = new decimal(new int[] {
            12000,
            0,
            0,
            0});
            this.portTextBox.Minimum = new decimal(new int[] {
            8000,
            0,
            0,
            0});
            this.portTextBox.Name = "portTextBox";
            this.portTextBox.Size = new System.Drawing.Size(120, 20);
            this.portTextBox.TabIndex = 6;
            this.portTextBox.Value = new decimal(new int[] {
            8000,
            0,
            0,
            0});
            // 
            // Options
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(345, 151);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.profilerLogGroup);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Options";
            this.Text = "Options";
            this.profilerLogGroup.ResumeLayout(false);
            this.profilerLogGroup.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.portTextBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckBox logCheckBox;
        private System.Windows.Forms.TextBox profilerLogPathTextBox;
        private System.Windows.Forms.GroupBox profilerLogGroup;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button browseButton;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown portTextBox;
        private System.Windows.Forms.Label label2;
    }
}