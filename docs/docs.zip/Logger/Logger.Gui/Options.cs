using System;
using System.Windows.Forms;
using Logger.Controller;

namespace Logger.Gui
{
    public partial class Options : Form
    {
        public Options()
        {
            InitializeComponent();
            logCheckBox.Checked = !string.IsNullOrEmpty(Configuration.ProfilerLogPath);
            profilerLogPathTextBox.Text = Configuration.ProfilerLogPath;
            portTextBox.Value = Configuration.Port;
            SetProfilerLogEnabledState();
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = false;

            if (logCheckBox.Checked)
            {
                if (string.IsNullOrEmpty(profilerLogPathTextBox.Text))
                {
                    MessageBox.Show(this, "Please select a log path.");
                    e.Cancel = true;
                }

                Configuration.ProfilerLogPath = profilerLogPathTextBox.Text;
            }
            else
            {
                Configuration.ProfilerLogPath = "";
            }

            Configuration.Port = (int)portTextBox.Value;

            base.OnClosing(e);
        }

        private void browseButton_Click(object sender, EventArgs e)
        {
            if (saveFileDialog.ShowDialog(this) != DialogResult.Cancel)
            {
                profilerLogPathTextBox.Text = saveFileDialog.FileName;
            }
        }

        private void logCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            SetProfilerLogEnabledState();
        }

        private void SetProfilerLogEnabledState()
        {

            browseButton.Enabled = logCheckBox.Checked;
            profilerLogPathTextBox.Enabled = logCheckBox.Checked;
        }
    }
}