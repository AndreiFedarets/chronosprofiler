#pragma once
#include "ProfilerBase.h"
#include "FunctionInfo.h"
#include "Helpers.h"
#include "Diagnostics.h"
#include "ILWriterBase.h"
#include "SmallILWriter.h"

[
	coclass,	
	threading("both"),
	vi_progid("Logger.Profiler"),
	progid("Logger.Profiler.1"),
	version(1.0),
	uuid("8782F5A0-E8B0-49af-B9D2-D0BE025D5D3E"),
	helpstring("Profiler Class")
]
class Profiler : 
	public ProfilerBase
{
public:
	Profiler();
	~Profiler();

	STDMETHOD(Initialize)(IUnknown *pICorProfilerInfoUnk);
	STDMETHOD(Shutdown)();
	STDMETHOD(JITCompilationStarted)(FunctionID functionId,BOOL fIsSafeToBlock);

private:
	ICorProfilerInfo *profilerInfo;
	
	ILWriterBase *CreateILWriter(FunctionInfo *functionInfo);
};
