#include "StdAfx.h"
#include "Diagnostics.h"

Diagnostics *Diagnostics::diagnostics = NULL;

Diagnostics::Diagnostics()
{	
	LPSTR log = new CHAR[MAX_LENGTH];
	ZeroMemory(log, MAX_LENGTH);
	GetEnvironmentVariableA("Logger_Profiler_Log", log, MAX_LENGTH);

	shouldLog = StrCmpA("\0", log);

	if(shouldLog)
	{
		stream = fopen(log, "w");
		fprintf(stream, "Diagnostics::Initialize");
	}
}

Diagnostics::~Diagnostics()
{
	if(shouldLog)
	{
		fprintf(stream, "\nDiagnostics::Shutdown");
		fflush(stream);
		fclose(stream);		
	}

	stream = NULL;
	delete stream;
}

void Diagnostics::Close()
{
	free(diagnostics);
}

Diagnostics *Diagnostics::GetInstance()
{
	if(NULL == diagnostics)
	{
		diagnostics = new Diagnostics();
	}
	return diagnostics;
}

void Diagnostics::PrintIL(BYTE* codeBytes, ULONG codeSize)
{
	if(shouldLog)
	{
		fprintf(stream, "\n\t");

		for(ULONG i = 0; i < codeSize; i++) 
		{
			if(codeBytes[i] > 0x0F) 
			{
				fprintf(stream, "0x%X; ", codeBytes[i]);
			} 
			else 
			{
				fprintf(stream, "0x0%X; ", codeBytes[i]);
			}
		}
	}
}

void Diagnostics::PrintMessage(const char *message)
{
	if(shouldLog)
	{
		fprintf(stream, message);
	}
}

void Diagnostics::PrintMessage(LPWSTR message)
{
	if(shouldLog)
	{
		fprintf(stream, "\n %S", message);
	}
}

void Diagnostics::PrintNumber(ULONG number)
{
	if(shouldLog)
	{
		fprintf(stream, " -> %d", number);
	}
}