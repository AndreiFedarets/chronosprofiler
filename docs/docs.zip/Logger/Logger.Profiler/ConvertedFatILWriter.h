#pragma once
#include "ILWriterBase.h"

class ConvertedFatILWriter : public ILWriterBase
{
friend class ILWriterBase;

private:
	ConvertedFatILWriter(ICorProfilerInfo *profilerInfo, FunctionInfo *functionInfo, LPCBYTE oldMethodBytes, ULONG oldMethodSize);
	~ConvertedFatILWriter(void);

	virtual ULONG GetHeaderSize();
	virtual ULONG GetOldHeaderSize();
	virtual ULONG GetOldMethodBodySize();
	virtual void WriteHeader(void* newMethodBytes);
};
