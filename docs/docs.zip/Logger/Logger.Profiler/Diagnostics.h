#pragma once

class Diagnostics
{
public:
	static Diagnostics *GetInstance();
	static void Close();

	void PrintIL(BYTE* codeBytes, ULONG codeSize);
	void PrintMessage(const char *message);
	void PrintMessage(LPWSTR message);
	void PrintNumber(ULONG number);
	
private:
	Diagnostics();
	~Diagnostics();
	
	static Diagnostics *diagnostics;

	BOOL shouldLog;
	FILE *stream;
};
