#include "StdAfx.h"
#include "SmallILWriter.h"

SmallILWriter::SmallILWriter(ICorProfilerInfo *profilerInfo, FunctionInfo *functionInfo, LPCBYTE oldMethodBytes, ULONG oldMethodSize) : ILWriterBase(profilerInfo, functionInfo, oldMethodBytes, oldMethodSize)
{
}

SmallILWriter::~SmallILWriter(void)
{
}

ULONG SmallILWriter::GetHeaderSize()
{
	return SMALL_HEADER_SIZE;
}

ULONG SmallILWriter::GetOldMethodBodySize()
{
	return ((COR_ILMETHOD_TINY*)GetOldMethodBytes())->GetCodeSize();
}

void SmallILWriter::WriteHeader(void* newMethodBytes) 
{	
	BYTE newCodeSizeWithoutHeader = (GetNewMethodBodySize() << 2 ) | CorILMethod_TinyFormat;
	memcpy((BYTE*)newMethodBytes, &newCodeSizeWithoutHeader, GetHeaderSize());
}