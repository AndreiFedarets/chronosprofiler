#include "StdAfx.h"
#include "Profiler.h"

Profiler::Profiler()
{	
}

Profiler::~Profiler()
{
}

HRESULT Profiler::Initialize(IUnknown *unknown)
{	
	unknown->QueryInterface(__uuidof(ICorProfilerInfo), (void**)&profilerInfo);
	profilerInfo->SetEventMask((DWORD) ( COR_PRF_MONITOR_JIT_COMPILATION ));
	return S_OK;
}

HRESULT Profiler::Shutdown()
{
	Diagnostics::Close();
	profilerInfo = NULL;
	return S_OK;
}

HRESULT Profiler::JITCompilationStarted(FunctionID functionID, BOOL fIsSafeToBlock)
{	
	FunctionInfo* functionInfo = FunctionInfo::CreateFunctionInfo(profilerInfo, functionID);
	if (NULL == functionInfo)
	{
		return S_OK;
	}

	ILWriterBase *ilWriter = ILWriterBase::CreateILWriter(profilerInfo, functionInfo);	
	if(ilWriter->CanRewrite())
	{
		Check(profilerInfo->SetILFunctionBody(functionInfo->GetModuleID(), functionInfo->GetToken(), (LPCBYTE)ilWriter->GetNewILBytes()));
	}

    return S_OK;
}