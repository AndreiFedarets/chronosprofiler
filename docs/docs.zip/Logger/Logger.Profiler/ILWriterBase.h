#pragma once
#include "FunctionInfo.h"
#include "Diagnostics.h"

#define FAT_HEADER_SIZE sizeof(WORD) + sizeof(WORD) + sizeof(DWORD) + sizeof(DWORD)
#define SMALL_HEADER_SIZE sizeof(BYTE)
#define MAX_TINY_FORMAT_SIZE 64

typedef struct
{
	BYTE nop;
	BYTE ldstr;
	BYTE stringToken[4];
	BYTE call;
	BYTE callToken[4];
} ILCode;


class ILWriterBase
{
public:
	ILWriterBase(ICorProfilerInfo *profilerInfo, FunctionInfo *functionInfo, LPCBYTE oldMethodBytes, ULONG oldMethodSize);
	~ILWriterBase(void);

	static ILWriterBase *CreateILWriter(ICorProfilerInfo *profilerInfo, FunctionInfo *functionInfo);

	virtual BOOL CanRewrite();
	void *GetNewILBytes();

protected:
	virtual ULONG GetOldMethodBodySize() = 0;
	virtual ULONG GetNewMethodSize();
	virtual ULONG GetHeaderSize() = 0;
	virtual ULONG GetOldHeaderSize();
	virtual void WriteHeader(void* newMethodBytes) = 0;
	virtual void WriteExtra(void* newMethodBytes);
	
	void *AllocateNewMethodBody(FunctionInfo *functionInfo);
	ILCode *CreateNewIL();
	LPCBYTE GetOldMethodBytes();
	ULONG GetOldMethodSize();
	ULONG GetNewMethodBodySize();

private:
	mdModuleRef GetAssemblyToken(IMetaDataEmit* metaDataEmit);
	void WriteNewIL(void *newMethodBytes);
	void WriteOldIL(void *newMethodBytes);

	ICorProfilerInfo *profilerInfo;
	FunctionInfo *functionInfo;
    LPCBYTE oldMethodBytes;
    ULONG oldMethodSize;

	static BOOL IsTiny(LPCBYTE methodBytes);
};
