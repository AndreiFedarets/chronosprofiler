#pragma once
#include "ILWriterBase.h"

class FatILWriter : public ILWriterBase
{
friend class ILWriterBase;

private:
	FatILWriter(ICorProfilerInfo *profilerInfo, FunctionInfo *functionInfo, LPCBYTE oldMethodBytes, ULONG oldMethodSize);
	~FatILWriter(void);

	virtual ULONG GetHeaderSize();
	virtual ULONG GetOldMethodBodySize();
	virtual ULONG GetNewMethodSize();
	virtual void WriteHeader(void* newMethodBytes);
	virtual void WriteExtra(void* newMethodBytes);
	virtual BOOL CanRewrite();
	
	BOOL HasSEH();
	COR_ILMETHOD_FAT *GetFatInfo();
	ULONG GetExtraSectionsSize();
	ULONG GetDWORDAlignmentOffset();
	ULONG GetOldMethodSizeWithoutExtraSections();
	void FixSEHSections(LPCBYTE methodBytes, ULONG newILSize);
};
