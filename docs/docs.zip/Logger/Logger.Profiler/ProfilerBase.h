#pragma once
#include "stdafx.h"

class ProfilerBase :
	public ICorProfilerCallback2
{
public:
	ProfilerBase(void){}
	~ProfilerBase(void){}

	STDMETHOD(Initialize)( IUnknown *pICorProfilerInfoUnk){return S_OK;}
    STDMETHOD(Shutdown)(){return S_OK;}
	STDMETHOD(AppDomainCreationStarted)( AppDomainID appDomainId){return S_OK;}
	STDMETHOD(AppDomainCreationFinished)( AppDomainID appDomainId, HRESULT hrStatus){return S_OK;}
	STDMETHOD(AppDomainShutdownStarted)( AppDomainID appDomainId){return S_OK;}
	STDMETHOD(AppDomainShutdownFinished)( AppDomainID appDomainId,HRESULT hrStatus){return S_OK;}
	STDMETHOD(AssemblyLoadStarted)( AssemblyID assemblyId){return S_OK;}
	STDMETHOD(AssemblyLoadFinished)( AssemblyID assemblyId,HRESULT hrStatus){return S_OK;}
	STDMETHOD(AssemblyUnloadStarted)( AssemblyID assemblyId){return S_OK;}
	STDMETHOD(AssemblyUnloadFinished)( AssemblyID assemblyId,HRESULT hrStatus){return S_OK;}
	STDMETHOD(ModuleLoadStarted)( ModuleID moduleId){return S_OK;}
	STDMETHOD(ModuleLoadFinished)( ModuleID moduleId,HRESULT hrStatus){return S_OK;}
	STDMETHOD(ModuleUnloadStarted)( ModuleID moduleId){return S_OK;}
	STDMETHOD(ModuleUnloadFinished)( ModuleID moduleId,HRESULT hrStatus){return S_OK;}
	STDMETHOD(ModuleAttachedToAssembly)( ModuleID moduleId,AssemblyID AssemblyId){return S_OK;}
	STDMETHOD(ClassLoadStarted)( ClassID classId){return S_OK;}
	STDMETHOD(ClassLoadFinished)(ClassID classId, HRESULT hrStatus){return S_OK;}
	STDMETHOD(ClassUnloadStarted)( ClassID classId){return S_OK;}
	STDMETHOD(ClassUnloadFinished)( ClassID classId,HRESULT hrStatus){return S_OK;}
	STDMETHOD(FunctionUnloadStarted)( FunctionID functionId){return S_OK;}
	STDMETHOD(JITCompilationStarted)( FunctionID functionId,BOOL fIsSafeToBlock){return S_OK;}
	STDMETHOD(JITCompilationFinished)( FunctionID functionId,HRESULT hrStatus,BOOL fIsSafeToBlock){return S_OK;}
	STDMETHOD(JITCachedFunctionSearchStarted)( FunctionID functionId,BOOL *pbUseCachedFunction){return S_OK;}
	STDMETHOD(JITCachedFunctionSearchFinished)( FunctionID functionId,COR_PRF_JIT_CACHE result){return S_OK;}
	STDMETHOD(JITFunctionPitched)( FunctionID functionId){return S_OK;}
	STDMETHOD(JITInlining)( FunctionID callerId,FunctionID calleeId,BOOL *pfShouldInline){return S_OK;}
	STDMETHOD(ThreadCreated)( ThreadID threadId){return S_OK;}
	STDMETHOD(ThreadDestroyed)( ThreadID threadId){return S_OK;}
	STDMETHOD(ThreadAssignedToOSThread)( ThreadID managedThreadId,DWORD osThreadId){return S_OK;}
	STDMETHOD(RemotingClientInvocationStarted)( void){return S_OK;}
	STDMETHOD(RemotingClientSendingMessage)( GUID *pCookie,BOOL fIsAsync){return S_OK;}
	STDMETHOD(RemotingClientReceivingReply)( GUID *pCookie,BOOL fIsAsync){return S_OK;}
	STDMETHOD(RemotingClientInvocationFinished)( void){return S_OK;}
	STDMETHOD(RemotingServerReceivingMessage)( GUID *pCookie,BOOL fIsAsync){return S_OK;}
	STDMETHOD(RemotingServerInvocationStarted)( void){return S_OK;}
	STDMETHOD(RemotingServerInvocationReturned)( void){return S_OK;}
	STDMETHOD(RemotingServerSendingReply)( GUID *pCookie,BOOL fIsAsync){return S_OK;}
	STDMETHOD(UnmanagedToManagedTransition)( FunctionID functionId,COR_PRF_TRANSITION_REASON reason){return S_OK;}
	STDMETHOD(ManagedToUnmanagedTransition)( FunctionID functionId,COR_PRF_TRANSITION_REASON reason){return S_OK;}
	STDMETHOD(RuntimeSuspendStarted)( COR_PRF_SUSPEND_REASON suspendReason){return S_OK;}
	STDMETHOD(RuntimeSuspendFinished)( void){return S_OK;}
	STDMETHOD(RuntimeSuspendAborted)( void){return S_OK;}
	STDMETHOD(RuntimeResumeStarted)( void){return S_OK;}
	STDMETHOD(RuntimeResumeFinished)( void){return S_OK;}
	STDMETHOD(RuntimeThreadSuspended)( ThreadID threadId){return S_OK;}
	STDMETHOD(RuntimeThreadResumed)( ThreadID threadId){return S_OK;}
	STDMETHOD(MovedReferences)( ULONG cMovedObjectIDRanges, ObjectID oldObjectIDRangeStart[  ],ObjectID newObjectIDRangeStart[  ],ULONG cObjectIDRangeLength[  ]){return S_OK;}
	STDMETHOD(ObjectAllocated)( ObjectID objectId,ClassID classId){return S_OK;}
	STDMETHOD(ObjectsAllocatedByClass)( ULONG cClassCount,ClassID classIds[  ],ULONG cObjects[  ]){return S_OK;}
	STDMETHOD(ObjectReferences)( ObjectID objectId,ClassID classId,ULONG cObjectRefs, ObjectID objectRefIds[  ]){return S_OK;}
	STDMETHOD(RootReferences)( ULONG cRootRefs,ObjectID rootRefIds[  ]){return S_OK;}
	STDMETHOD(ExceptionThrown)( ObjectID thrownObjectId){return S_OK;}
	STDMETHOD(ExceptionSearchFunctionEnter)( FunctionID functionId){return S_OK;}
	STDMETHOD(ExceptionSearchFunctionLeave)( void){return S_OK;}
	STDMETHOD(ExceptionSearchFilterEnter)( FunctionID functionId){return S_OK;}
	STDMETHOD(ExceptionSearchFilterLeave)( void){return S_OK;}
	STDMETHOD(ExceptionSearchCatcherFound)( FunctionID functionId){return S_OK;}
	STDMETHOD(ExceptionOSHandlerEnter)( UINT_PTR __unused){return S_OK;}
	STDMETHOD(ExceptionOSHandlerLeave)( UINT_PTR __unused){return S_OK;}
	STDMETHOD(ExceptionUnwindFunctionEnter)( FunctionID functionId){return S_OK;}
	STDMETHOD(ExceptionUnwindFunctionLeave)( void){return S_OK;}
	STDMETHOD(ExceptionUnwindFinallyEnter)( FunctionID functionId){return S_OK;}
	STDMETHOD(ExceptionUnwindFinallyLeave)( void){return S_OK;}
	STDMETHOD(ExceptionCatcherEnter)( FunctionID functionId,ObjectID objectId){return S_OK;}
	STDMETHOD(ExceptionCatcherLeave)( void){return S_OK;}
	STDMETHOD(COMClassicVTableCreated)( ClassID wrappedClassId,REFGUID implementedIID,void *pVTable,ULONG cSlots){return S_OK;}
	STDMETHOD(COMClassicVTableDestroyed)( ClassID wrappedClassId,REFGUID implementedIID,void *pVTable){return S_OK;}
	STDMETHOD(ExceptionCLRCatcherFound)( void){return S_OK;}
	STDMETHOD(ExceptionCLRCatcherExecute)( void){return S_OK;}
	STDMETHOD(ThreadNameChanged)(ThreadID threadId, ULONG cchName, WCHAR name[]){return S_OK;}
	STDMETHOD(GarbageCollectionStarted)(int cGenerations, BOOL generationCollected[], COR_PRF_GC_REASON reason){return S_OK;}
    STDMETHOD(SurvivingReferences)(ULONG cSurvivingObjectIDRanges, ObjectID objectIDRangeStart[], ULONG cObjectIDRangeLength[]){return S_OK;}
    STDMETHOD(GarbageCollectionFinished)(){return S_OK;}
    STDMETHOD(FinalizeableObjectQueued)(DWORD finalizerFlags, ObjectID objectID){return S_OK;}
    STDMETHOD(RootReferences2)(ULONG cRootRefs, ObjectID rootRefIds[], COR_PRF_GC_ROOT_KIND rootKinds[], COR_PRF_GC_ROOT_FLAGS rootFlags[], UINT_PTR rootIds[]){return S_OK;}
    STDMETHOD(HandleCreated)(GCHandleID handleId, ObjectID initialObjectId){return S_OK;}
    STDMETHOD(HandleDestroyed)(GCHandleID handleId){return S_OK;}
};
