#pragma once
#include "ILWriterBase.h"

class SmallILWriter : public ILWriterBase
{
friend class ILWriterBase;

private:
	SmallILWriter(ICorProfilerInfo *profilerInfo, FunctionInfo *functionInfo, LPCBYTE oldMethodBytes, ULONG oldMethodSize);
	~SmallILWriter(void);

	virtual ULONG GetHeaderSize();
	virtual ULONG GetOldMethodBodySize();
	virtual void WriteHeader(void* newMethodBytes);
};
