// Logger.Profiler.cpp : Implementation of DLL Exports.


#include "stdafx.h"
#include "resource.h"


// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{8D74745D-72BA-4B1A-AEFF-AE6C9804DF43}", 
		 name = "LoggerProfiler", 
		 helpstring = "Logger.Profiler 1.0 Type Library",
		 resource_name = "IDR_LOGGERPROFILER") ]
class CLoggerProfilerModule
{
public:
// Override CAtlDllModuleT members
};
		 
