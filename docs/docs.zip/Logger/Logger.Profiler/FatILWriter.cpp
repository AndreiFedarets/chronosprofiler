#include "StdAfx.h"
#include "FatILWriter.h"

FatILWriter::FatILWriter(ICorProfilerInfo *profilerInfo, FunctionInfo *functionInfo, LPCBYTE oldMethodBytes, ULONG oldMethodSize) : ILWriterBase(profilerInfo, functionInfo, oldMethodBytes, oldMethodSize)
{
}

FatILWriter::~FatILWriter(void)
{
}

COR_ILMETHOD_FAT *FatILWriter::GetFatInfo()
{
	return (COR_ILMETHOD_FAT*)GetOldMethodBytes();
}

ULONG FatILWriter::GetHeaderSize()
{
	return FAT_HEADER_SIZE;
}

ULONG FatILWriter::GetOldMethodBodySize()
{
	return GetFatInfo()->GetCodeSize();
}

ULONG FatILWriter::GetNewMethodSize()
{
	return ILWriterBase::GetNewMethodSize()  + GetDWORDAlignmentOffset();
}

BOOL FatILWriter::HasSEH()
{
	return (GetFatInfo()->GetFlags() & CorILMethod_MoreSects);
}

ULONG FatILWriter::GetExtraSectionsSize()
{
	return GetOldMethodSize() - GetOldMethodSizeWithoutExtraSections();
}

ULONG FatILWriter::GetOldMethodSizeWithoutExtraSections()
{
	return GetHeaderSize() + GetOldMethodBodySize();
}

ULONG FatILWriter::GetDWORDAlignmentOffset()
{
	if(!HasSEH())
	{
		return 0;
	}
	else
	{
		ULONG totalDelta = ( (sizeof(ILCode) + GetOldMethodSizeWithoutExtraSections()) % sizeof(DWORD) );

		ULONG newDelta = 0;	
		if ( totalDelta != 0 )
		{
			newDelta = sizeof(DWORD) - totalDelta; 
		}

		ULONG oldDelta = (int)( (BYTE*)GetFatInfo()->GetSect() - (BYTE*)((BYTE*)GetOldMethodBytes() + GetOldMethodSizeWithoutExtraSections()) );
		
		return newDelta - oldDelta;
	}
}

BOOL FatILWriter::CanRewrite()
{
	if(HasSEH())
	{
		COR_ILMETHOD_DECODER method( (const COR_ILMETHOD*)GetOldMethodBytes() );
		COR_ILMETHOD_SECT_EH* currentEHSection = (COR_ILMETHOD_SECT_EH*)method.EH;
		
		do
		{
			for (UINT i = 0; i < currentEHSection->EHCount(); ++i )
			{
				if (!currentEHSection->IsFat() && ( (currentEHSection->Small.Clauses[i].TryOffset + sizeof(ILCode)) > 0xFFFF || (currentEHSection->Small.Clauses[i].HandlerOffset + sizeof(ILCode)) > 0xFFFF ))
				{	
					Diagnostics::GetInstance()->PrintMessage(" -> Don't log. Can't modify small EH clasue if it's bigger then 2 bytes");
					return FALSE;
				}
			}

			do
			{
				currentEHSection = (COR_ILMETHOD_SECT_EH*)currentEHSection->Next();
			} while ( currentEHSection && (currentEHSection->Kind() & CorILMethod_Sect_KindMask) != CorILMethod_Sect_EHTable );

		} while (currentEHSection);
	}

	return TRUE;
}

void FatILWriter::WriteHeader(void *newMethodBytes) 
{	
	WORD maxStackSize = (WORD)GetFatInfo()->MaxStack + ( sizeof(ILCode) / 2 ); // rough estimation
	DWORD newSize = GetNewMethodBodySize();

	memcpy((BYTE*)newMethodBytes, GetOldMethodBytes(), GetHeaderSize());
	memcpy((BYTE*)newMethodBytes + sizeof(WORD), &maxStackSize, sizeof(WORD));
	memcpy((BYTE*)newMethodBytes + sizeof(WORD) + sizeof(WORD), &newSize, sizeof(DWORD));
}

void FatILWriter::WriteExtra(void *newMethodBytes)
{	
	memcpy((BYTE*)newMethodBytes + GetHeaderSize() + sizeof(ILCode) + GetOldMethodBodySize(), (BYTE*)GetOldMethodBytes() + (GetOldMethodSize() - GetExtraSectionsSize() - GetDWORDAlignmentOffset()), GetExtraSectionsSize());

	if(HasSEH())
	{
		Diagnostics::GetInstance()->PrintMessage(" -> HAS TRY/CATCH (SEH)");
		FixSEHSections((LPCBYTE)newMethodBytes, sizeof(ILCode));
	}
}

void FatILWriter::FixSEHSections( LPCBYTE methodBytes, ULONG newILSize)
{
	COR_ILMETHOD_DECODER method( (const COR_ILMETHOD*)methodBytes );
	COR_ILMETHOD_SECT_EH* currentEHSection = (COR_ILMETHOD_SECT_EH*)method.EH;
	
    do
	{
        for (UINT i = 0; i < currentEHSection->EHCount(); ++i )
		{
			if (currentEHSection->IsFat())
			{
				if ( currentEHSection->Fat.Clauses[i].Flags == COR_ILEXCEPTION_CLAUSE_FILTER )
				{
					currentEHSection->Fat.Clauses[i].FilterOffset += newILSize;
				}
				
				currentEHSection->Fat.Clauses[i].TryOffset += newILSize;
				currentEHSection->Fat.Clauses[i].HandlerOffset += newILSize;
			} 
			else
			{
				if ( currentEHSection->Small.Clauses[i].Flags == COR_ILEXCEPTION_CLAUSE_FILTER)
				{
					currentEHSection->Small.Clauses[i].FilterOffset += newILSize;
				}

				currentEHSection->Small.Clauses[i].TryOffset += newILSize;
				currentEHSection->Small.Clauses[i].HandlerOffset += newILSize;
			}
		}

        do
		{
            currentEHSection = (COR_ILMETHOD_SECT_EH*)currentEHSection->Next();
        } while ( currentEHSection && (currentEHSection->Kind() & CorILMethod_Sect_KindMask) != CorILMethod_Sect_EHTable );

    } while (currentEHSection);
}