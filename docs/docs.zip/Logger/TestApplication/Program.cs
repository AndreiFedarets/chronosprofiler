using System;
using System.Collections.Generic;
namespace TestApplication
{
    class Program
    {
        public static void Main(string[] args)
        {
            SimpleSmallHeaderTest();
            SimpleFatHeaderTest();
            TryCatchTest();
            SmallHeaderThatWillBecomeAFatHeader();
            SimpleArray(null, 0);
            ArrayOfArrays(null, null);
            MultiArray(null, null, false, 0);
            GenericList(null, null);
            GenericDictionary(null, 0, DateTime.Now);
            Delegate(null, null);

            Console.ReadKey();
        }

        private static void SimpleSmallHeaderTest()
        {
            Console.WriteLine("SimpleTest");
        }

        private static string SimpleFatHeaderTest()
        {
            Console.WriteLine("SimpleFatHeaderTest");
            return "SimpleFatHeaderTest";
        }

        private static void TryCatchTest()
        {
            Console.WriteLine("test");

            try
            {
                Console.WriteLine("TryCatchTest");
                throw new Exception("test");
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.ToString());
            }
        }

        private static void SmallHeaderThatWillBecomeAFatHeader()
        {
            Console.WriteLine("SmallHeaderThatWillBecomeAFatHeader");
            Console.WriteLine("SmallHeaderThatWillBecomeAFatHeader");
            Console.WriteLine("SmallHeaderThatWillBecomeAFatHeader");
            Console.WriteLine("SmallHeaderThatWillBecomeAFatHeader");
            Console.WriteLine("SmallHeaderThatWillBecomeAFatHeader");
        }

        private static void SimpleArray(string[] args, decimal args2)
        {
            Console.WriteLine("SimpleArray");

        }

        private static void ArrayOfArrays(int[][] args, string args2)
        {
            Console.WriteLine("SizedArray");
        }

        private static void GenericList(List<Guid> args, object args2)
        {
            Console.WriteLine("GenericList");
        }

        private static Dictionary<DateTime, Double> GenericDictionary(Dictionary<string,int> args, int args2, DateTime args3)
        {
            Console.WriteLine("GenericDictionary");
            return null;
        }

        private static int MultiArray(int[,] args, string[,,] args2, bool args3, int args4)
        {
            Console.WriteLine("MultiArray");
            return 0;
        }

        private static string Delegate(EventHandler args, string args2)
        {
            Console.WriteLine("Delegate");
            return null;
        }
    }
}
