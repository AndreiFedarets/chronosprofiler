using System;
using System.Threading;
using Logger.Common;

namespace Logger.Core
{
    public static class Logger
    {
        private static IMessageLogger messageLogger;

        static Logger()
        {
            messageLogger = (IMessageLogger)Activator.GetObject(typeof(IMessageLogger), string.Format("tcp://localhost:{0}/MessageManager.rem", Environment.GetEnvironmentVariable("Logger_Profiler_Port")));
        }

        public static void Log(string method)
        {
            ThreadPool.QueueUserWorkItem(new WaitCallback(ProcessMessage), new LogInfo(method));
        }

        private static void ProcessMessage(object state)
        {
            messageLogger.LogMessage(((LogInfo)state).FormattedCallInfo);
        }
    }
}