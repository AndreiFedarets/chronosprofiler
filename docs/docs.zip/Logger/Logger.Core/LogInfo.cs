using System;
using System.Threading;

namespace Logger.Core
{
    public class LogInfo
    {
        private DateTime time;
        private int threadID;
        private string methodInfo;

        public LogInfo(string method)
        {
            this.time = DateTime.Now; //NativeMethods.GetTickCount();
            this.threadID = Thread.CurrentThread.ManagedThreadId;
            this.methodInfo = method;
        }

        public string FormattedCallInfo
        {
            get { return string.Format(@"{0}|{1}|{2}", methodInfo, time.ToBinary(), threadID); }
        }
    }
}
