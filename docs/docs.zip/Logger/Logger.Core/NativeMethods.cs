using System;
using System.Runtime.InteropServices;

namespace Logger.Core
{
    public static class NativeMethods
    {
        [DllImport("Kernel32")]
        public static extern long GetTickCount();
    }
}
