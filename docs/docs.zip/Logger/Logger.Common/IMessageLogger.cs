using System;

namespace Logger.Common
{
    public interface IMessageLogger
    {
        void LogMessage(string callInfo);
    }
}
