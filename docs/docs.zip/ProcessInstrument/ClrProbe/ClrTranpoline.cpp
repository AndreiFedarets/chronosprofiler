#include "stdafx.h"
#include "ClrProbe.h"

namespace {
struct __declspec(uuid("D9A7CDDF-75EF-4988-9C9D-4FD00A0B9363"))
ITranpolineInit : IUnknown
{
      virtual HRESULT __stdcall SetupAppDomain() = 0;	
};
}

LPSAFEARRAY GetClrHookDllAsSafeArray()
{
	//- Load the resource (mapped in memory)
	HRSRC hClrHookDllRes = FindResource(g_hInst,MAKEINTRESOURCE(IDR_CLRHOOKDLL),L"BINDATA");
	if(hClrHookDllRes==NULL)
	{
		DBGERR("GetClrHookDllAsSafeArray - FindResource(IDR_CLRHOOKDLL) failed : {0}") % DBGLASTERROR();
		_ComOp( E_FAIL );
	}

	HGLOBAL hClrHookDllHGlb = LoadResource(g_hInst,hClrHookDllRes);
	if(hClrHookDllHGlb==NULL)
	{
		DBGERR("GetClrHookDllAsSafeArray - LoadResource failed : {0}") % DBGLASTERROR();
		_ComOp( E_FAIL );
	}

	DWORD dllMemorySize = SizeofResource(g_hInst,hClrHookDllRes);
	DBGINF("GetClrHookDllAsSafeArray - Size of CLRHOOK.DLL in resource : {0} bytes") % dllMemorySize;

	LPBYTE lpDllData = (LPBYTE)LockResource(hClrHookDllHGlb);
	if(lpDllData==NULL)
	{
		DBGERR("GetClrHookDllAsSafeArray - LockResource failed : {0}") % DBGLASTERROR();
		_ComOp( E_FAIL );
	}

	//- Create SAFEARRAY
	SAFEARRAYBOUND bound = {0};
	bound.cElements = dllMemorySize;
	bound.lLbound   = 0;

	LPBYTE lpArrayData;
	LPSAFEARRAY lpAsmblyData = SafeArrayCreate(VT_UI1,1,&bound);
	if(lpAsmblyData==NULL)
	{
		DBGERR("GetClrHookDllAsSafeArray - SafeArrayCreate(VT_UI1,1,[0-{0}] failed") % dllMemorySize;
		_ComOp( E_OUTOFMEMORY );
	}

	_ComOp( SafeArrayAccessData(lpAsmblyData, (void**)&lpArrayData) );
	memcpy(lpArrayData,lpDllData,dllMemorySize);
	SafeArrayUnaccessData (lpAsmblyData);

	return lpAsmblyData;
}

EXTERN_C HRESULT STDAPICALLTYPE PIAttachDomain(IUnknown *p)
{
	try
	{
	CComPtr<mscorlib::_AppDomain> pAppDomain;
	_ComOp( p->QueryInterface(__uuidof(mscorlib::_AppDomain),(void**)&pAppDomain) );
	
	LPSAFEARRAY lpAsmblyData = GetClrHookDllAsSafeArray();

	CComPtr<mscorlib::_Assembly> pAssembly;
	HRESULT hr = pAppDomain->Load_3(lpAsmblyData,&pAssembly);
	SafeArrayDestroy(lpAsmblyData);
	if(FAILED(hr)) 
	{
		DBGERR("PIAttachDomain - pAppDomain->Load_3 failed {0}") % DBGHRESULT(hr);
		return hr;
	}

	CComVariant variant;
	_ComOp( pAssembly->CreateInstance( _bstr_t(L"ClrHook.TranpolineInit"),&variant) );
	CComPtr<ITranpolineInit> pTranpolineInit;
	_ComOp( variant.punkVal->QueryInterface( __uuidof(ITranpolineInit), (void**)&pTranpolineInit ) );
	hr = pTranpolineInit->SetupAppDomain();

	}
	catch(_com_error &e)
	{
		DBGERR("InstrumentModule - Failed: {0}") % e;
		return e.Error();
	}
	return S_OK;
}