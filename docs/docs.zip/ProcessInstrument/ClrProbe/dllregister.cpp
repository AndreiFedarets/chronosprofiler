#include "stdafx.h"
#include "ClrProbe.h"

#pragma warning(disable: 4995)

//.............................................................................
/** Convert a CLSID to TCHAR */
static bool Clsid2Tchar (const CLSID &clsid, LPTSTR szBuffer, DWORD dwBufferSize)
{
	LPWSTR   pwsz;

	//get the CLSID in string form
	StringFromIID(clsid, &pwsz);

	if(pwsz)
	{
	   StringCchCopyW(szBuffer,dwBufferSize,pwsz);

		//free the string
		LPMALLOC pMalloc;
		CoGetMalloc(1, &pMalloc);
		pMalloc->Free(pwsz);
		pMalloc->Release();

		return true;
	}

	return false;
}

//.............................................................................
/** Register a CLSID COM */
static bool RegisterAClass(const TCHAR *szModule,const CLSID &clsid, LPCTSTR lpszTitle)
{
	typedef struct{
		HKEY	hRootKey;
		LPCTSTR	szSubKey;
		LPCTSTR	lpszValueName;
		LPCTSTR	szData;
	} DOREGSTRUCT, *LPDOREGSTRUCT;

	int      i;
	HKEY     hKey;
	LRESULT  lResult;
	DWORD    dwDisp;
	TCHAR    szSubKey[MAX_PATH];
	TCHAR    szCLSID[MAX_PATH];
	TCHAR	 szData[MAX_PATH];

	if (!Clsid2Tchar (clsid,szCLSID,sizeof(szCLSID)/sizeof(TCHAR))) return false;

	DOREGSTRUCT ClsidEntries[] = 
			{HKEY_CLASSES_ROOT,   TEXT("CLSID\\%s"),                  NULL,                   lpszTitle,
             HKEY_CLASSES_ROOT,   TEXT("CLSID\\%s\\InprocServer32"),  NULL,                   szModule,
			 HKEY_CLASSES_ROOT,   TEXT("CLSID\\%s\\InprocServer32"),  TEXT("ThreadingModel"), _T("Both"),
			 HKEY_CLASSES_ROOT,   TEXT("CLSID\\%s\\TypeLib"),		  NULL,					  TEXT("{00008888-2A16-462a-CE48-59573FFF0000}"),
			 HKEY_CLASSES_ROOT,   TEXT("CLSID\\%s\\Version"),		  NULL,					  TEXT("1.0"),
             NULL,                NULL,                               NULL,                   NULL};
	 
	//register the CLSID entries
	for(i = 0; ClsidEntries[i].hRootKey; ++i)
	{
		//create the sub key string - for this case, insert the file extension
		StringCchPrintf(szSubKey,MAX_PATH,ClsidEntries[i].szSubKey,szCLSID);

		lResult = RegCreateKeyEx(  ClsidEntries[i].hRootKey,
                              szSubKey,
                              0,
                              NULL,
                              REG_OPTION_NON_VOLATILE,
                              KEY_WRITE,
                              NULL,
                              &hKey,
                              &dwDisp);
   
		if(NOERROR == lResult)
		{
			// if necessary, create the value string
			StringCchPrintf(szData,MAX_PATH, ClsidEntries[i].szData, szModule);
			lResult = RegSetValueEx(   hKey,
                                 ClsidEntries[i].lpszValueName,
                                 0,
                                 REG_SZ,
                                 (LPBYTE)szData,
                                 (_tcslen(szData) + 1)*sizeof(TCHAR));
      
			RegCloseKey(hKey);
		}
		else
			return false;
	}

	return true;
}

//.............................................................................
/** Register a CLSID COM */
static bool UnRegisterAClass(const CLSID &clsid)
{
	TCHAR    szCLSID [MAX_PATH];
	TCHAR    szSubKey[MAX_PATH];

	if (!Clsid2Tchar (clsid,szCLSID,sizeof(szCLSID)/sizeof(TCHAR))) return false;
	StringCchPrintf(szSubKey,MAX_PATH, _T("CLSID\\%s"), szCLSID);
	SHDeleteKey(HKEY_CLASSES_ROOT,szSubKey);

	return true;
}

STDAPI DllRegisterServer()
{
	TCHAR    szModule[MAX_PATH];

	GetModuleFileName(g_hInst, szModule, sizeof(szModule)/sizeof(TCHAR));


	if(!RegisterAClass(szModule,CLSID_LDsCLRProble, L"Laurent Dupuis's CLR Probe engine"))
	{
		DBGERR("Failed to register module");
		return E_FAIL;
	}
	return S_OK;
}

STDAPI DllUnregisterServer(void)
{
	UnRegisterAClass(CLSID_LDsCLRProble);
	return S_OK;
}

