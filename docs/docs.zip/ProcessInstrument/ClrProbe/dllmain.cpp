#include "stdafx.h"
#include "ClrProbe.h"

static LONG sg_references = 0;

HINSTANCE g_hInst = 0;

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		if(InterlockedIncrement(&sg_references)==1)
		{
			DBGINF("DLL Attached");
			AllocConsole();
			g_hInst = hModule;
		}
		break;
	case DLL_PROCESS_DETACH:
		if(InterlockedDecrement(&sg_references)==0)
		{
			DBGINF("DLL Detached");
		}
		break;

	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
		break;
	}
	return TRUE;
}

