#include "stdafx.h"
#include "ClrProbe.h"

static BYTE sg_sigPIAttach[] = { 
		0, // IMAGE_CEE_CS_CALLCONV_DEFAULT
		1, // argument count
		0x1, // ret = ELEMENT_TYPE_VOID
		ELEMENT_TYPE_OBJECT
}; 
static BYTE sg_sigPIHook[] = { 
		0, // IMAGE_CEE_CS_CALLCONV_DEFAULT
		1, // argument count
		0x1, // ret = ELEMENT_TYPE_VOID
		ELEMENT_TYPE_SZARRAY,
		ELEMENT_TYPE_OBJECT
}; 


namespace {
#pragma pack(push)
#pragma pack(1)
struct injectorCCTOR {
	BYTE	methodHeader;			// TINY format header

	BYTE	ilCall01;
	DWORD	refGetAppDomain;
	BYTE	ilCall02;
	DWORD	refPIAttachDomain;
	BYTE	ilRet;

	injectorCCTOR(mdMethodDef tkGetAppDomain,mdMethodDef tkAttachDomain)
	{
		ilCall01 = ilCall02 = 0x28;
		ilRet	 = 0x2A;
		refGetAppDomain		= tkGetAppDomain;
		refPIAttachDomain	= tkAttachDomain;

		methodHeader = CorILMethod_TinyFormat|((sizeof(injectorCCTOR)-1)<<(CorILMethod_FormatShift-1));
	}
};
struct injectorTranpoline {
	BYTE	methodHeader;			// TINY format header

	BYTE	ilCall01;
	DWORD	refTranpoline;
	BYTE	ilRet;

	injectorTranpoline(mdMethodDef tkClrHook)
	{
		ilCall01		= 0x28;
		refTranpoline	= tkClrHook;
		ilRet			= 0x2A;

		methodHeader = CorILMethod_TinyFormat|((sizeof(injectorTranpoline)-1)<<(CorILMethod_FormatShift-1));
	}
};
#pragma pack(pop)

class ModuleInstrumenter
{
	CComPtr<IMetaDataEmit>			pMetaEmit;
	CComPtr<IMetaDataImport2>		pMetaImport;
	CComPtr<IMetaDataAssemblyEmit>	pAsmEmit;
	CComPtr<IMethodMalloc>			pMethodAlloc;
	CComPtr<ICorProfilerInfo2>		pCorInfos;
	ModuleID						moduleID;

	mdModuleRef		tkRefClrProbe;
	mdAssemblyRef	tkRefMsCorLib,tkRefClrHook;
	mdTypeDef		tkSysObject,tkAppDomain,tkHookClass;
	mdMethodDef		tkGetAppDomain;
	mdMethodDef		tkClrHook;
	mdMethodDef		tkClrMethod;

	void AppendReferences()
	{
		ASSEMBLYMETADATA amd = {0};

		// ClrHook, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null

		// Inject module/assembly references
		_ComOp( pAsmEmit->DefineAssemblyRef	( NULL, 0, L"mscorlib", &amd, NULL, 0, 0, &tkRefMsCorLib) );
		_ComOp( pAsmEmit->DefineAssemblyRef	( NULL, 0, L"ClrHook",  &amd, NULL, 0, 0, &tkRefClrHook) );
		_ComOp( pMetaEmit->DefineModuleRef	( L"CLRPROBE.DLL", &tkRefClrProbe ) );
		
		// Inject required type reference
		_ComOp( pMetaEmit->DefineTypeRefByName(tkRefMsCorLib,L"System.Object",	  &tkSysObject) );
		_ComOp( pMetaEmit->DefineTypeRefByName(tkRefMsCorLib,L"System.AppDomain", &tkAppDomain) );
		_ComOp( pMetaEmit->DefineTypeRefByName(tkRefClrHook, L"ClrHook.HookClass",&tkHookClass) );

		// Create a reference for System.AppDomain.get_CurrentDomain
		BYTE importSig[] = { IMAGE_CEE_CS_CALLCONV_DEFAULT,0 /*<no args*/,0x12 /*< ret class*/,0,0,0,0,0 };
		ULONG l = CorSigCompressToken(tkAppDomain,importSig+3);	//< Add the System.AppDomain token ref
		_ComOp( pMetaEmit->DefineMemberRef(	tkAppDomain,L"get_CurrentDomain",
					importSig,3+l,&tkGetAppDomain	) );		

		BYTE importSigHook[] = { IMAGE_CEE_CS_CALLCONV_DEFAULT,0 /*<no args*/,ELEMENT_TYPE_VOID /*< void*/ };
		_ComOp( pMetaEmit->DefineMemberRef(	tkHookClass,L"TestHook",
			importSigHook,sizeof(importSigHook),&tkClrHook	) );		

	}

	void CreateInjectorClass()
	{
		//- Inject a class into the module
		mdTypeDef	tkInjClass;

		std::wstringstream classId;
		classId << L"__ClrProbeInjection_" << GetTickCount();
		_ComOp( pMetaEmit->DefineTypeDef( classId.str().c_str(),tdAbstract|tdSealed, tkSysObject, NULL, &tkInjClass ));
		
		// Add PInvoke method for PIAttachDomain attach point
		mdMethodDef	tkAttachDomain;
		_ComOp( pMetaEmit->DefineMethod	( tkInjClass, L"PIAttachDomain",
				mdStatic|mdPinvokeImpl,
				sg_sigPIAttach,sizeof(sg_sigPIAttach),
				0,0,&tkAttachDomain
			) );

		{
		BYTE tiunk = NATIVE_TYPE_IUNKNOWN;
		mdParamDef paramDef;
		_ComOp( pMetaEmit->DefinePinvokeMap ( tkAttachDomain, 0, L"PIAttachDomain", tkRefClrProbe ) );
		_ComOp( pMetaEmit->DefineParam		( tkAttachDomain, 1, L"appDomain", 
												pdIn|pdHasFieldMarshal, 0, NULL, 0, &paramDef ) );
		_ComOp( pMetaEmit->SetFieldMarshal	( paramDef, &tiunk, 1 ) );
		}

		// Define a static constructor for hooking the class
		{
			BYTE cctorSig[] = {IMAGE_CEE_CS_CALLCONV_DEFAULT,0,ELEMENT_TYPE_VOID};
			injectorCCTOR cctor(tkGetAppDomain,tkAttachDomain);
			mdMethodDef	  tkcctor;

			_ComOp( pMetaEmit->DefineMethod ( tkInjClass, L".cctor",
				mdStatic|mdSpecialName|mdRTSpecialName,
				cctorSig,sizeof(cctorSig),NULL,0,&tkcctor ) );
			LPBYTE method = (LPBYTE)pMethodAlloc->Alloc(sizeof(cctor));
			memcpy(method,&cctor,sizeof(cctor));
			_ComOp( pCorInfos->SetILFunctionBody(moduleID,tkcctor,(LPCBYTE)method) );
		}

		// Define a static constructor for hooking the class
		{
			BYTE trmpSig[] = {IMAGE_CEE_CS_CALLCONV_DEFAULT,0,ELEMENT_TYPE_VOID};
			injectorTranpoline tranpoline(tkClrHook);

			_ComOp( pMetaEmit->DefineMethod ( tkInjClass, L"Tranpoline",
				mdStatic|mdPublic, trmpSig,sizeof(trmpSig),NULL,0,&tkClrMethod ) );
			LPBYTE method = (LPBYTE)pMethodAlloc->Alloc(sizeof(tranpoline));
			memcpy(method,&tranpoline,sizeof(tranpoline));
			_ComOp( pCorInfos->SetILFunctionBody(moduleID,tkClrMethod,(LPCBYTE)method) );
		}
	}

	bool appendSimpleType(BYTE typeId,std::wstringstream &methodId)
	{
		switch(typeId)
		{
		case ELEMENT_TYPE_VOID:		methodId << L"void";	return true;
		case ELEMENT_TYPE_BOOLEAN:	methodId << L"bool";	return true;
		case ELEMENT_TYPE_CHAR:		methodId << L"char";	return true;
		case ELEMENT_TYPE_I1:		methodId << L"int8";	return true;
		case ELEMENT_TYPE_U1:		methodId << L"byte";	return true;
		case ELEMENT_TYPE_I2:		methodId << L"short";	return true;
		case ELEMENT_TYPE_U2:		methodId << L"ushort";	return true;
		case ELEMENT_TYPE_I4:		methodId << L"int";		return true;
		case ELEMENT_TYPE_U4:		methodId << L"uint";	return true;
		case ELEMENT_TYPE_I8:		methodId << L"long";	return true;
		case ELEMENT_TYPE_U8:		methodId << L"ulong";	return true;
		case ELEMENT_TYPE_R4:		methodId << L"float";	return true;
		case ELEMENT_TYPE_R8:		methodId << L"double";	return true;
		case ELEMENT_TYPE_STRING:	methodId << L"string";	return true;
		case ELEMENT_TYPE_OBJECT:	methodId << L"object";	return true;
		case ELEMENT_TYPE_I:		methodId << L"natint";	return true;
		case ELEMENT_TYPE_U:		methodId << L"natuint";	return true;
		}
		return false;
	}

	void appendTypeName(LPCBYTE &signInfo,LPCBYTE end,std::wstringstream &methodId)
	{
		mdToken tkTypeId;
		DWORD	len;

		_ComOp( CorSigUncompressToken(  signInfo, end-signInfo, &tkTypeId, &len ) );
		signInfo+=len;

		DWORD		 flags;
		std::wstring name;
		if(!GetTypeInfos(tkTypeId,name,flags))
		{
			if(!GetTypeRefInfos(tkTypeId,name)) name=L"$UNK$";
		}
		methodId << name;
	}


	void appendTypeinfo(LPCBYTE &signInfo,LPCBYTE end,std::wstringstream &methodId)
	{
		if(appendSimpleType(*signInfo,methodId)) { ++signInfo; return; }

		switch(*signInfo)
		{
		case ELEMENT_TYPE_PTR:
			methodId << L"ptr ";++signInfo;
			appendTypeinfo(signInfo,end,methodId);
			break;
		case ELEMENT_TYPE_BYREF:
			methodId << L"ref ";++signInfo;
			appendTypeinfo(signInfo,end,methodId);
			break;
		case ELEMENT_TYPE_VALUETYPE:
			methodId << L"val ";++signInfo;
			appendTypeName(signInfo,end,methodId);
			break;
		case ELEMENT_TYPE_CLASS:
			++signInfo;
			appendTypeName(signInfo,end,methodId);
			break;

		case ELEMENT_TYPE_GENERICINST:
		{
			++signInfo;
			appendTypeName(signInfo,end,methodId);
			BYTE nbArgs = *signInfo; ++signInfo;
			methodId << '<';
			for(BYTE arg=0;arg<nbArgs;arg++)
			{
				if(arg) methodId << ',';
				appendTypeinfo(signInfo,end,methodId);
			}
			methodId << '>';
			break;
		}
		case ELEMENT_TYPE_SZARRAY:	
		{
			methodId << L"array";
			++signInfo;
			appendTypeName(signInfo,end,methodId);
			break;
		}



		case ELEMENT_TYPE_ARRAY:
			++signInfo;
			appendTypeName(signInfo,end,methodId);
			_ComOp( E_NOTIMPL );

		default:
			_ComOp( E_NOTIMPL );
		}
	}


public:
	ModuleInstrumenter(const CComPtr<ICorProfilerInfo2> &corInfos,ModuleID moduleId) 
		: pCorInfos(corInfos), moduleID(moduleId)
	{
		_ComOp( pCorInfos->GetILFunctionBodyAllocator( moduleID, &pMethodAlloc ) );
		_ComOp( pCorInfos->GetModuleMetaData( 
					moduleId, 
					ofRead | ofWrite, 
					IID_IMetaDataEmit,
					(IUnknown**)&pMetaEmit ) 
		);
		_ComOp( pMetaEmit->QueryInterface( IID_IMetaDataAssemblyEmit, (void**)&pAsmEmit		) );
		_ComOp( pMetaEmit->QueryInterface( IID_IMetaDataImport2,	  (void**)&pMetaImport	) );
	}


	void InstrumentModule()
	{
		AppendReferences	();
		CreateInjectorClass	();
	}

	std::list<mdTypeDef> GetAllTypes()
	{
		HCORENUM  hcorEnum = NULL;
		mdTypeDef rTypeDefs[128];
		ULONG     cTypeDefs	=	sizeof(rTypeDefs)/sizeof(rTypeDefs[0]);
		std::list<mdTypeDef> allTypes;

		while( S_OK == _ComOp( pMetaImport->EnumTypeDefs( &hcorEnum, rTypeDefs, cTypeDefs, &cTypeDefs ) ) )
		{
			allTypes.insert( allTypes.end(), rTypeDefs, rTypeDefs + cTypeDefs );
			cTypeDefs	=	sizeof(rTypeDefs)/sizeof(rTypeDefs[0]);
		}

		return allTypes;
	}

	bool GetTypeRefInfos(mdTypeDef tkType,std::wstring &name)
	{
		wchar_t wszTypeRef[512];
		DWORD cchTypeRef = sizeof(wszTypeRef)/sizeof(wszTypeRef[0]);
		mdToken tkAssembly;

		HRESULT hr = _ComOp( pMetaImport->GetTypeRefProps( tkType, &tkAssembly,wszTypeRef,cchTypeRef,&cchTypeRef) );
		if(hr==S_FALSE) return false;
		name.assign( wszTypeRef );
		return true;
	}

	bool GetTypeInfos(mdTypeDef tkType,std::wstring &name,DWORD &flags)
	{
		wchar_t wszTypeDef[512];
		DWORD cchTypeDef = sizeof(wszTypeDef)/sizeof(wszTypeDef[0]);

		HRESULT hr = _ComOp( pMetaImport->GetTypeDefProps( tkType, wszTypeDef, cchTypeDef, &cchTypeDef, &flags, NULL ) );
		if(hr==S_FALSE) return false;
		name.assign( wszTypeDef );
		return true;
	}

	std::list<mdMethodDef> GetTypeMethods(mdTypeDef tkType)
	{
		HCORENUM  hcorEnum = NULL;
		std::list<mdMethodDef> allMethods;
		mdMethodDef  rMethods[128];
		ULONG     cMethods	=	sizeof(rMethods)/sizeof(rMethods[0]);
		while( S_OK == _ComOp( pMetaImport->EnumMethods( &hcorEnum, tkType,
						rMethods, cMethods, &cMethods ) ) )
		{
			allMethods.insert( allMethods.end(), rMethods, rMethods + cMethods );
			cMethods	=	sizeof(rMethods)/sizeof(rMethods[0]);
		}

		return allMethods;
	}

	void GetMethodInfos(mdMethodDef tkMethod,std::wstring &name)
	{
		wchar_t wszMethod[512];
		DWORD cchMethod = sizeof(wszMethod)/sizeof(wszMethod[0]);
		PCCOR_SIGNATURE	signature;
		ULONG			cbSignature;
		DWORD			dwImplFlags,dwAttr;

		_ComOp( pMetaImport->GetMethodProps (tkMethod,NULL,wszMethod,cchMethod,&cchMethod,
				&dwAttr,&signature,&cbSignature,NULL,&dwImplFlags) );
		std::wstringstream methodId;

		switch(dwAttr & mdMemberAccessMask)
		{
		case mdPrivate:	methodId << L"private ";	break;
		case mdAssem:	methodId << L"internal ";	break;
		case mdPublic:	methodId << L"public ";		break;
		}
		if(dwAttr & mdStatic)	methodId << L"static ";

		try
		{
			LPCBYTE signInfo = signature+2;
			appendTypeinfo(signInfo,signature+cbSignature,methodId);
			methodId<< ' ' << wszMethod << '(';
			for(BYTE u=0;u<signature[1];++u)
			{
				if(u) methodId<< ',';
				appendTypeinfo(signInfo,signature+cbSignature,methodId);
			}
			methodId<< ')';
		}
		catch(_com_error &e)
		{
			DBGERR("ModuleInstrumenter::GetMethodInfos - Failed: {0}") % e;
			methodId<< L"$$FAILED";
		}

		name = methodId.str();
	}

	void InstrumentMethod(mdMethodDef tkMethod)
	{
		LPCBYTE pMethodHeader = NULL;
		ULONG	iMethodSize = 0;

		_ComOp( pCorInfos->GetILFunctionBody	(moduleID, tkMethod, &pMethodHeader, &iMethodSize) );

		if(  ((COR_ILMETHOD_FAT*)&((IMAGE_COR_ILMETHOD*)pMethodHeader)->Fat)->IsFat())
		{
#include <pshpack1.h>
			struct { BYTE nulLd; BYTE call; DWORD method_token; } ILCode;
#include <poppack.h>

			ILCode.nulLd	= 0; //0x14;	// LDNULL
			ILCode.call		= 0x28;
			ILCode.method_token = tkClrMethod;

			COR_ILMETHOD_FAT* fatImage = (COR_ILMETHOD_FAT*)&((IMAGE_COR_ILMETHOD*)pMethodHeader)->Fat;
			IMAGE_COR_ILMETHOD* pNewMethod = (IMAGE_COR_ILMETHOD*) pMethodAlloc->Alloc(iMethodSize+sizeof(ILCode));
			if(pNewMethod==NULL)
			{
				DBGERR("ModuleInstrumenter::InstrumentMethod - Unable to alloc new method (size={0})") % (iMethodSize+sizeof(ILCode));
				return;
			}
			COR_ILMETHOD_FAT* newFatImage = (COR_ILMETHOD_FAT*)&pNewMethod->Fat;
			memcpy((BYTE*)newFatImage, (BYTE*)fatImage, fatImage->Size * sizeof(DWORD));
			memcpy(newFatImage->GetCode(), (BYTE*)&ILCode, sizeof(ILCode));
			memcpy(newFatImage->GetCode() + sizeof(ILCode), fatImage->GetCode(),  fatImage->CodeSize);
			
			newFatImage->CodeSize += sizeof(ILCode);

			_ComOp( pCorInfos->SetILFunctionBody(moduleID,tkMethod,(LPCBYTE) pNewMethod) );
		}
		else
		{
			DBGINF("ModuleInstrumenter::InstrumentMethod - Method not fat - MethodSize={0}") % iMethodSize;
		}
	}


};
}

bool InstrumentModule(
		const CComPtr<ICorProfilerInfo2> &corInfos,
		ModuleID	moduleId)
{
	try
	{
		ModuleInstrumenter	instrument(corInfos,moduleId);

		instrument.InstrumentModule();


		std::list<mdTypeDef> allTypes = instrument.GetAllTypes();
		for(std::list<mdTypeDef>::iterator iType=allTypes.begin();iType!=allTypes.end();++iType)
		{
			DWORD		 typeFlag;
			std::wstring typeName;

			instrument.GetTypeInfos(*iType,typeName,typeFlag);
			if(!_wcsicmp(typeName.c_str(),L"TestApplication.Form1"))
			{
				std::list<mdMethodDef> allMethods = instrument.GetTypeMethods(*iType);
				for(std::list<mdMethodDef>::iterator iMeth=allMethods.begin();iMeth!=allMethods.end();++iMeth)
				{
					std::wstring methodName;
					
					instrument.GetMethodInfos(*iMeth,methodName);
					DBGINF("InstrumentModule - Detected method: {0} {1}") % typeName % methodName;

					if(!_wcsicmp(methodName.c_str(),L"private void button1_Click(object,System.EventArgs)"))
						instrument.InstrumentMethod(*iMeth);
				}
			}
		}
	}
	catch(_com_error &e)
	{
		DBGERR("InstrumentModule - Failed: {0}") % e;
		return false;
	}
	return true;
}