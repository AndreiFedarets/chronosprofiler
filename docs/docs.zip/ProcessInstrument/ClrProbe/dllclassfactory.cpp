#include "stdafx.h"
#include "ClrProbe.h"

//.............................................................................
// Generic Class Factory
template<typename ClsImpl>
class CObjectCF : public IClassFactory 
{
public:
	//.........................................................................
    // Real live constructor
	CObjectCF() : m_cRef(1) {}
//	~CObjectCF();

	//.........................................................................
    // IUnknown methods 
    STDMETHOD(QueryInterface) (REFIID riid, LPVOID FAR* ppvObj)
	{
		*ppvObj = NULL;
	    
		if (riid == IID_IUnknown || riid == IID_IClassFactory)
		{
			*ppvObj = this;
			AddRef();
			return S_OK;    
		}

		return E_NOINTERFACE; 
	}

    STDMETHOD_(ULONG, AddRef) (void)
	{
		return InterlockedIncrement(&m_cRef);
	}
    STDMETHOD_(ULONG, Release)(void)
	{   
		LONG cRef;
		cRef=InterlockedDecrement(&m_cRef);
		if(cRef == 0)
		{
			delete this;
			return 0;
		}
		return cRef;
	}    
	//.........................................................................
    // IClassFactory methods
	STDMETHOD(LockServer)(BOOL fLock)
	{
		return S_OK;
	}

    STDMETHOD(CreateInstance)(IUnknown FAR* punkOuter, REFIID riid, 
                              void FAR* FAR* ppv)
	{
		HRESULT hr;
	    
		*ppv = NULL;
	    
		// This implementation does'nt allow aggregation
		if (punkOuter) return CLASS_E_NOAGGREGATION;

		CComPtr<IUnknown> iObjRef;  

		iObjRef.Attach( reinterpret_cast<IUnknown *>( new ClsImpl ) );
		hr = iObjRef->QueryInterface (riid, ppv);
		return hr;
	}
    
private:
    LONG  m_cRef;           // Reference count
};

//.............................................................................

#define MULTIUSE_CLASSFACTORY(clsid,type)		\
	if( rclsid == clsid )						\
	{											\
		factory.Attach( reinterpret_cast<IClassFactory*>(	\
		new CObjectCF<type>									\
		) );												\
		goto clsFactoryBuilded;					\
	}


//=============================================================================
/** Point d'entr�e COM - Demande une r�f�rence sur le ClassFactory d'un objet */
STDAPI DllGetClassObject(  REFCLSID rclsid, 
                           REFIID riid, 
                           LPVOID *ppReturn)
{
	*ppReturn = NULL;

	CComPtr<IClassFactory> factory;

	MULTIUSE_CLASSFACTORY	(CLSID_LDsCLRProble,CClrProbeProfiler);

	//if we don't support this classid, return the proper error code
	return CLASS_E_CLASSNOTAVAILABLE;

clsFactoryBuilded:
	if(NULL == factory) return E_OUTOFMEMORY;

	//get the QueryInterface return for our return value
	return factory->QueryInterface(riid, ppReturn);
}

STDAPI DllCanUnloadNow()
{
	return S_FALSE;
}