#include "stdafx.h"
#include "ClrProbe.h"

STDMETHODIMP CClrProbeProfiler::Initialize( 
            /* [in] */ IUnknown *pICorProfilerInfoUnk) 
{
	m_tkCurAppDomain=0;
	DBGNOT("CClrProbeProfiler::Initialize - Attach profiler");
	m_corInfos.Release();
	HRESULT hr=pICorProfilerInfoUnk->QueryInterface(__uuidof(ICorProfilerInfo2),(void**)&m_corInfos);
	if(FAILED(hr))
	{
		DBGERR("CClrProbeProfiler::Initialize - Failed to get ICorProfilerInfo2 : {0}") % DBGHRESULT(hr);
	}
	else
	{
		hr=m_corInfos->SetEventMask(
			COR_PRF_MONITOR_APPDOMAIN_LOADS|
			COR_PRF_MONITOR_ASSEMBLY_LOADS|
			COR_PRF_MONITOR_MODULE_LOADS |
			COR_PRF_MONITOR_JIT_COMPILATION );
		if(FAILED(hr)) 
		{
			DBGERR("CClrProbeProfiler::Initialize - m_corInfos->SetEventMask Failed : {0}") % DBGHRESULT(hr);
		}
	}
	return hr; 
}
        
STDMETHODIMP CClrProbeProfiler::Shutdown( void) 
{
	DBGNOT("CClrProbeProfiler::Shutdown - Detach profiler");
	m_corInfos.Release();
	return S_OK; 
}

STDMETHODIMP CClrProbeProfiler::JITCompilationStarted( 
            /* [in] */ FunctionID functionId,
            /* [in] */ BOOL fIsSafeToBlock) 
{ 
#if 0
	ClassID classID;
	ModuleID moduleID;
	mdToken tkMethod;

	try
	{
		_ComOp( m_corInfos->GetFunctionInfo		(functionId,&classID,&moduleID,&tkMethod) );

		wchar_t wszMethod[512];
		wchar_t wszTypeDef[512];
		mdToken methodDef;
		CComPtr<IMetaDataImport> metaData;
		
		_ComOp( m_corInfos->GetTokenAndMetaDataFromFunction(
			functionId, IID_IMetaDataImport,
			(LPUNKNOWN *)&metaData, &methodDef ) );

		DWORD cchMethod = sizeof(wszMethod)/sizeof(wszMethod[0]);
		mdTypeDef mdClass;

		_ComOp( metaData->GetMethodProps( methodDef, &mdClass, wszMethod,
					cchMethod, &cchMethod, 0, 0, 0, 0, 0 ) );     

		DWORD cchTypeDef = sizeof(wszTypeDef)/sizeof(wszTypeDef[0]);

		if ( mdClass == 0x02000000 ) mdClass = 0x02000001;
		_ComOp( metaData->GetTypeDefProps( mdClass, wszTypeDef, cchTypeDef,&cchTypeDef, 0, 0 ) );

		DBGINF("CClrProbeProfiler::JITCompilationStarted - FunctionID={0} {1}::{2}") % functionId % wszTypeDef % wszMethod;
		if(moduleID!=m_targetModuleId) return S_OK;
	}
	catch(_com_error &e)
	{
		DBGERR("CClrProbeProfiler::JITCompilationStarted - Get Name failed {0}") % e;
		return E_FAIL;
	}
#endif
	return S_OK; 
}
        
STDMETHODIMP CClrProbeProfiler::JITCompilationFinished( 
            /* [in] */ FunctionID functionId,
            /* [in] */ HRESULT hrStatus,
            /* [in] */ BOOL fIsSafeToBlock) 
{ 
	if(FAILED(hrStatus))
	{
		DBGNOT("CClrProbeProfiler::JITCompilationFinished - FunctionID={0}") % functionId;
	}
	return S_OK; 
}

        
STDMETHODIMP CClrProbeProfiler::AppDomainCreationStarted( 
            /* [in] */ AppDomainID appDomainId) 
{ 
	DBGNOT("CClrProbeProfiler::AppDomainCreationStarted - appDomainId={0}") % appDomainId;
	return S_OK; 
}
        
STDMETHODIMP CClrProbeProfiler::AppDomainCreationFinished( 
            /* [in] */ AppDomainID appDomainId,
            /* [in] */ HRESULT hrStatus) 
{ 
	if(FAILED(hrStatus))
	{
		DBGNOT("CClrProbeProfiler::AppDomainCreationFinished - appDomainId={0} HR={1}") % appDomainId % DBGHRESULT(hrStatus);
	}
	return S_OK; 
}
        
STDMETHODIMP CClrProbeProfiler::AppDomainShutdownStarted( 
            /* [in] */ AppDomainID appDomainId) 
{
	DBGNOT("CClrProbeProfiler::AppDomainShutdownStarted - appDomainId={0}") % appDomainId;
	return S_OK; 
}
        
STDMETHODIMP CClrProbeProfiler::AppDomainShutdownFinished( 
            /* [in] */ AppDomainID appDomainId,
            /* [in] */ HRESULT hrStatus) 
{ 
	if(FAILED(hrStatus))
	{
		DBGNOT("CClrProbeProfiler::AppDomainShutdownFinished - appDomainId={0} HR={1}") % appDomainId % DBGHRESULT(hrStatus);
	}
	return S_OK; 
}
        
STDMETHODIMP CClrProbeProfiler::AssemblyLoadStarted( 
            /* [in] */ AssemblyID assemblyId) 
{ 
	return S_OK; 
}
        
STDMETHODIMP CClrProbeProfiler::AssemblyLoadFinished( 
            /* [in] */ AssemblyID assemblyId,
            /* [in] */ HRESULT hrStatus) 
{ 
	if(FAILED(hrStatus))
	{
		wchar_t wszAssembly	[512];
		DWORD cchAssembly	= sizeof(wszAssembly)/sizeof(wszAssembly[0]);
		HRESULT hr = m_corInfos->GetAssemblyInfo(assemblyId,cchAssembly,&cchAssembly,wszAssembly,NULL,NULL);
		if(FAILED(hr)) {wszAssembly[0]='?';wszAssembly[1]=0;}
		DBGNOT("CClrProbeProfiler::AssemblyLoadFinished - AssemblyID={0} [{1}] HR={2}") % assemblyId % wszAssembly % DBGHRESULT(hrStatus);
	}
	return S_OK; 
}
        
STDMETHODIMP CClrProbeProfiler::AssemblyUnloadStarted( 
            /* [in] */ AssemblyID assemblyId) 
{ 
	return S_OK; 
}
        
STDMETHODIMP CClrProbeProfiler::AssemblyUnloadFinished( 
            /* [in] */ AssemblyID assemblyId,
            /* [in] */ HRESULT hrStatus) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ModuleLoadStarted( 
            /* [in] */ ModuleID moduleId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ModuleLoadFinished( 
            /* [in] */ ModuleID moduleId,
            /* [in] */ HRESULT hrStatus) 
{ 
	if(FAILED(hrStatus)) return S_OK;

	try
	{
		AssemblyID assemblyId;
		wchar_t wszModule	[512];
		wchar_t wszAssembly	[512];
		LPCBYTE    ppBaseLoadAddress;
		DWORD cchAssembly	= sizeof(wszAssembly)/sizeof(wszAssembly[0]);
		DWORD cchModule		= sizeof(wszModule)/sizeof(wszModule[0]);

		_ComOp( m_corInfos->GetModuleInfo  (moduleId,&ppBaseLoadAddress,cchModule,&cchModule,wszModule,&assemblyId) );
		_ComOp( m_corInfos->GetAssemblyInfo(assemblyId,cchAssembly,&cchAssembly,wszAssembly,NULL,NULL) );

		DBGNOT("CClrProbeProfiler::ModuleLoadFinished - ModuleID={0} [{1}] of AssemblyID={2} [{3}]") % moduleId % wszModule % assemblyId % wszAssembly;

		if(!_wcsicmp(wszAssembly,L"TestApplication"))
		{
			DBGNOT("CClrProbeProfiler::ModuleLoadFinished - Instrument module");
			InstrumentModule(m_corInfos,moduleId);
		}
	}
	catch(_com_error &e)
	{
		DBGERR("CClrProbeProfiler::ModuleLoadFinished - Get Module Name failed {0}") % e;
		return E_FAIL;
	}
	return S_OK; 
}
        
STDMETHODIMP CClrProbeProfiler::ModuleUnloadStarted( 
            /* [in] */ ModuleID moduleId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ModuleUnloadFinished( 
            /* [in] */ ModuleID moduleId,
            /* [in] */ HRESULT hrStatus) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ModuleAttachedToAssembly( 
            /* [in] */ ModuleID moduleId,
            /* [in] */ AssemblyID AssemblyId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ClassLoadStarted( 
            /* [in] */ ClassID classId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ClassLoadFinished( 
            /* [in] */ ClassID classId,
            /* [in] */ HRESULT hrStatus) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ClassUnloadStarted( 
            /* [in] */ ClassID classId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ClassUnloadFinished( 
            /* [in] */ ClassID classId,
            /* [in] */ HRESULT hrStatus) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::FunctionUnloadStarted( 
            /* [in] */ FunctionID functionId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::JITCachedFunctionSearchStarted( 
            /* [in] */ FunctionID functionId,
            /* [out] */ BOOL *pbUseCachedFunction) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::JITCachedFunctionSearchFinished( 
            /* [in] */ FunctionID functionId,
            /* [in] */ COR_PRF_JIT_CACHE result) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::JITFunctionPitched( 
            /* [in] */ FunctionID functionId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::JITInlining( 
            /* [in] */ FunctionID callerId,
            /* [in] */ FunctionID calleeId,
            /* [out] */ BOOL *pfShouldInline) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ThreadCreated( 
            /* [in] */ ThreadID threadId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ThreadDestroyed( 
            /* [in] */ ThreadID threadId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ThreadAssignedToOSThread( 
            /* [in] */ ThreadID managedThreadId,
            /* [in] */ DWORD osThreadId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::RemotingClientInvocationStarted( void) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::RemotingClientSendingMessage( 
            /* [in] */ GUID *pCookie,
            /* [in] */ BOOL fIsAsync) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::RemotingClientReceivingReply( 
            /* [in] */ GUID *pCookie,
            /* [in] */ BOOL fIsAsync) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::RemotingClientInvocationFinished( void) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::RemotingServerReceivingMessage( 
            /* [in] */ GUID *pCookie,
            /* [in] */ BOOL fIsAsync) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::RemotingServerInvocationStarted( void) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::RemotingServerInvocationReturned( void) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::RemotingServerSendingReply( 
            /* [in] */ GUID *pCookie,
            /* [in] */ BOOL fIsAsync) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::UnmanagedToManagedTransition( 
            /* [in] */ FunctionID functionId,
            /* [in] */ COR_PRF_TRANSITION_REASON reason) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ManagedToUnmanagedTransition( 
            /* [in] */ FunctionID functionId,
            /* [in] */ COR_PRF_TRANSITION_REASON reason) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::RuntimeSuspendStarted( 
            /* [in] */ COR_PRF_SUSPEND_REASON suspendReason) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::RuntimeSuspendFinished( void) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::RuntimeSuspendAborted( void) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::RuntimeResumeStarted( void) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::RuntimeResumeFinished( void) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::RuntimeThreadSuspended( 
            /* [in] */ ThreadID threadId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::RuntimeThreadResumed( 
            /* [in] */ ThreadID threadId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::MovedReferences( 
            /* [in] */ ULONG cMovedObjectIDRanges,
            /* [size_is][in] */ ObjectID oldObjectIDRangeStart[  ],
            /* [size_is][in] */ ObjectID newObjectIDRangeStart[  ],
            /* [size_is][in] */ ULONG cObjectIDRangeLength[  ]) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ObjectAllocated( 
            /* [in] */ ObjectID objectId,
            /* [in] */ ClassID classId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ObjectsAllocatedByClass( 
            /* [in] */ ULONG cClassCount,
            /* [size_is][in] */ ClassID classIds[  ],
            /* [size_is][in] */ ULONG cObjects[  ]) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ObjectReferences( 
            /* [in] */ ObjectID objectId,
            /* [in] */ ClassID classId,
            /* [in] */ ULONG cObjectRefs,
            /* [size_is][in] */ ObjectID objectRefIds[  ]) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::RootReferences( 
            /* [in] */ ULONG cRootRefs,
            /* [size_is][in] */ ObjectID rootRefIds[  ]) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ExceptionThrown( 
            /* [in] */ ObjectID thrownObjectId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ExceptionSearchFunctionEnter( 
            /* [in] */ FunctionID functionId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ExceptionSearchFunctionLeave( void) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ExceptionSearchFilterEnter( 
            /* [in] */ FunctionID functionId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ExceptionSearchFilterLeave( void) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ExceptionSearchCatcherFound( 
            /* [in] */ FunctionID functionId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ExceptionOSHandlerEnter( 
            /* [in] */ UINT_PTR __unused) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ExceptionOSHandlerLeave( 
            /* [in] */ UINT_PTR __unused) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ExceptionUnwindFunctionEnter( 
            /* [in] */ FunctionID functionId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ExceptionUnwindFunctionLeave( void) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ExceptionUnwindFinallyEnter( 
            /* [in] */ FunctionID functionId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ExceptionUnwindFinallyLeave( void) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ExceptionCatcherEnter( 
            /* [in] */ FunctionID functionId,
            /* [in] */ ObjectID objectId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ExceptionCatcherLeave( void) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::COMClassicVTableCreated( 
            /* [in] */ ClassID wrappedClassId,
            /* [in] */ REFGUID implementedIID,
            /* [in] */ void *pVTable,
            /* [in] */ ULONG cSlots) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::COMClassicVTableDestroyed( 
            /* [in] */ ClassID wrappedClassId,
            /* [in] */ REFGUID implementedIID,
            /* [in] */ void *pVTable) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ExceptionCLRCatcherFound( void) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::ExceptionCLRCatcherExecute( void) { return S_OK; }


	//.........................................................................
    // ICorProfilerInfo2 methods 
STDMETHODIMP CClrProbeProfiler::ThreadNameChanged( 
            /* [in] */ ThreadID threadId,
            /* [in] */ ULONG cchName,
            /* [in] */ 
            __in_ecount_opt(cchName)  WCHAR name[  ]) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::GarbageCollectionStarted( 
            /* [in] */ int cGenerations,
            /* [size_is][in] */ BOOL generationCollected[  ],
            /* [in] */ COR_PRF_GC_REASON reason) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::SurvivingReferences( 
            /* [in] */ ULONG cSurvivingObjectIDRanges,
            /* [size_is][in] */ ObjectID objectIDRangeStart[  ],
            /* [size_is][in] */ ULONG cObjectIDRangeLength[  ]) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::GarbageCollectionFinished( void) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::FinalizeableObjectQueued( 
            /* [in] */ DWORD finalizerFlags,
            /* [in] */ ObjectID objectID) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::RootReferences2( 
            /* [in] */ ULONG cRootRefs,
            /* [size_is][in] */ ObjectID rootRefIds[  ],
            /* [size_is][in] */ COR_PRF_GC_ROOT_KIND rootKinds[  ],
            /* [size_is][in] */ COR_PRF_GC_ROOT_FLAGS rootFlags[  ],
            /* [size_is][in] */ UINT_PTR rootIds[  ]) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::HandleCreated( 
            /* [in] */ GCHandleID handleId,
            /* [in] */ ObjectID initialObjectId) { return S_OK; }
        
STDMETHODIMP CClrProbeProfiler::HandleDestroyed( 
            /* [in] */ GCHandleID handleId) { return S_OK; }

