#pragma once

#include "resource.h"

// {139008CF-ED57-49c1-B840-2DEA89B6C76C}
extern const CLSID __declspec(selectany) CLSID_LDsCLRProble = { 0x139008cf, 0xed57, 0x49c1, { 0xb8, 0x40, 0x2d, 0xea, 0x89, 0xb6, 0xc7, 0x6c } };

extern HINSTANCE g_hInst;

bool InstrumentModule(const CComPtr<ICorProfilerInfo2> &corInfos,ModuleID	moduleId);

//.............................................................................
// Profiler interface
class CClrProbeProfiler : public ICorProfilerCallback2 
{
    LONG						m_cRef;     // Reference count
	CComPtr<ICorProfilerInfo2>	m_corInfos;	// Profiler API
	mdMethodDef					m_tkCurAppDomain,m_tkTestHook;
	ModuleID					m_targetModuleId;
public:
	//.........................................................................
    // Real live constructor
	CClrProbeProfiler() : m_cRef(1) {}
//	~CObjectCF();

	//.........................................................................
    // IUnknown methods 
    STDMETHOD(QueryInterface) (REFIID riid, LPVOID FAR* ppvObj)
	{
		*ppvObj = NULL;
	    
		if (riid == IID_IUnknown || 
			riid == __uuidof(ICorProfilerCallback) || 
			riid == __uuidof(ICorProfilerCallback2))
		{
			*ppvObj = this;
			AddRef();
			return S_OK;    
		}

		return E_NOINTERFACE; 
	}

    STDMETHOD_(ULONG, AddRef) (void)
	{
		return InterlockedIncrement(&m_cRef);
	}
    STDMETHOD_(ULONG, Release)(void)
	{   
		LONG cRef;
		cRef=InterlockedDecrement(&m_cRef);
		if(cRef == 0)
		{
			delete this;
			return 0;
		}
		return cRef;
	}  

	//.........................................................................
    // ICorProfilerCallback methods 
	STDMETHOD(Initialize)( 
            /* [in] */ IUnknown *pICorProfilerInfoUnk);
        
	STDMETHOD(Shutdown)(void);
        
	STDMETHOD(AppDomainCreationStarted)(
            /* [in] */ AppDomainID appDomainId);
        
	STDMETHOD(AppDomainCreationFinished)( 
            /* [in] */ AppDomainID appDomainId,
            /* [in] */ HRESULT hrStatus);
        
	STDMETHOD(AppDomainShutdownStarted)(
            /* [in] */ AppDomainID appDomainId);
        
	STDMETHOD(AppDomainShutdownFinished)(
            /* [in] */ AppDomainID appDomainId,
            /* [in] */ HRESULT hrStatus);
        
	STDMETHOD(AssemblyLoadStarted)(
            /* [in] */ AssemblyID assemblyId);
        
	STDMETHOD(AssemblyLoadFinished)(
            /* [in] */ AssemblyID assemblyId,
            /* [in] */ HRESULT hrStatus);
        
	STDMETHOD(AssemblyUnloadStarted)(
            /* [in] */ AssemblyID assemblyId);
        
	STDMETHOD(AssemblyUnloadFinished)(
            /* [in] */ AssemblyID assemblyId,
            /* [in] */ HRESULT hrStatus);
        
	STDMETHOD(ModuleLoadStarted)(
            /* [in] */ ModuleID moduleId);
        
	STDMETHOD(ModuleLoadFinished)(
            /* [in] */ ModuleID moduleId,
            /* [in] */ HRESULT hrStatus);
        
	STDMETHOD(ModuleUnloadStarted)(
            /* [in] */ ModuleID moduleId);
        
	STDMETHOD(ModuleUnloadFinished)(
            /* [in] */ ModuleID moduleId,
            /* [in] */ HRESULT hrStatus);
        
	STDMETHOD(ModuleAttachedToAssembly)(
            /* [in] */ ModuleID moduleId,
            /* [in] */ AssemblyID AssemblyId);
        
	STDMETHOD(ClassLoadStarted)(
            /* [in] */ ClassID classId);
        
	STDMETHOD(ClassLoadFinished)(
            /* [in] */ ClassID classId,
            /* [in] */ HRESULT hrStatus);
        
	STDMETHOD(ClassUnloadStarted)(
            /* [in] */ ClassID classId);
        
	STDMETHOD(ClassUnloadFinished)(
            /* [in] */ ClassID classId,
            /* [in] */ HRESULT hrStatus);
        
	STDMETHOD(FunctionUnloadStarted)(
            /* [in] */ FunctionID functionId);
        
	STDMETHOD(JITCompilationStarted)(
            /* [in] */ FunctionID functionId,
            /* [in] */ BOOL fIsSafeToBlock);
        
	STDMETHOD(JITCompilationFinished)(
            /* [in] */ FunctionID functionId,
            /* [in] */ HRESULT hrStatus,
            /* [in] */ BOOL fIsSafeToBlock);
        
	STDMETHOD(JITCachedFunctionSearchStarted)(
            /* [in] */ FunctionID functionId,
            /* [out] */ BOOL *pbUseCachedFunction);
        
	STDMETHOD(JITCachedFunctionSearchFinished)(
            /* [in] */ FunctionID functionId,
            /* [in] */ COR_PRF_JIT_CACHE result);
        
	STDMETHOD(JITFunctionPitched)(
            /* [in] */ FunctionID functionId);
        
	STDMETHOD(JITInlining)(
            /* [in] */ FunctionID callerId,
            /* [in] */ FunctionID calleeId,
            /* [out] */ BOOL *pfShouldInline);
        
	STDMETHOD(ThreadCreated)(
            /* [in] */ ThreadID threadId);
        
	STDMETHOD(ThreadDestroyed)(
            /* [in] */ ThreadID threadId);
        
	STDMETHOD(ThreadAssignedToOSThread)(
            /* [in] */ ThreadID managedThreadId,
            /* [in] */ DWORD osThreadId);
        
	STDMETHOD(RemotingClientInvocationStarted)(void);
        
	STDMETHOD(RemotingClientSendingMessage)(
            /* [in] */ GUID *pCookie,
            /* [in] */ BOOL fIsAsync);
        
	STDMETHOD(RemotingClientReceivingReply)(
            /* [in] */ GUID *pCookie,
            /* [in] */ BOOL fIsAsync);
        
	STDMETHOD(RemotingClientInvocationFinished)(void);
        
	STDMETHOD(RemotingServerReceivingMessage)(
            /* [in] */ GUID *pCookie,
            /* [in] */ BOOL fIsAsync);
        
	STDMETHOD(RemotingServerInvocationStarted)(void);
        
	STDMETHOD(RemotingServerInvocationReturned)(void);
        
	STDMETHOD(RemotingServerSendingReply)(
            /* [in] */ GUID *pCookie,
            /* [in] */ BOOL fIsAsync);
        
	STDMETHOD(UnmanagedToManagedTransition)(
            /* [in] */ FunctionID functionId,
            /* [in] */ COR_PRF_TRANSITION_REASON reason);
        
	STDMETHOD(ManagedToUnmanagedTransition)(
            /* [in] */ FunctionID functionId,
            /* [in] */ COR_PRF_TRANSITION_REASON reason);
        
	STDMETHOD(RuntimeSuspendStarted)(
            /* [in] */ COR_PRF_SUSPEND_REASON suspendReason);
        
	STDMETHOD(RuntimeSuspendFinished)(void);
        
	STDMETHOD(RuntimeSuspendAborted)(void);
        
	STDMETHOD(RuntimeResumeStarted)(void);
        
	STDMETHOD(RuntimeResumeFinished)(void);
        
	STDMETHOD(RuntimeThreadSuspended)(
            /* [in] */ ThreadID threadId);
        
	STDMETHOD(RuntimeThreadResumed)(
            /* [in] */ ThreadID threadId);
        
	STDMETHOD(MovedReferences)(
            /* [in] */ ULONG cMovedObjectIDRanges,
            /* [size_is][in] */ ObjectID oldObjectIDRangeStart[  ],
            /* [size_is][in] */ ObjectID newObjectIDRangeStart[  ],
            /* [size_is][in] */ ULONG cObjectIDRangeLength[  ]);
        
	STDMETHOD(ObjectAllocated)(
            /* [in] */ ObjectID objectId,
            /* [in] */ ClassID classId);
        
	STDMETHOD(ObjectsAllocatedByClass)(
            /* [in] */ ULONG cClassCount,
            /* [size_is][in] */ ClassID classIds[  ],
            /* [size_is][in] */ ULONG cObjects[  ]);
        
	STDMETHOD(ObjectReferences)(
            /* [in] */ ObjectID objectId,
            /* [in] */ ClassID classId,
            /* [in] */ ULONG cObjectRefs,
            /* [size_is][in] */ ObjectID objectRefIds[  ]);
        
	STDMETHOD(RootReferences)(
            /* [in] */ ULONG cRootRefs,
            /* [size_is][in] */ ObjectID rootRefIds[  ]);
        
	STDMETHOD(ExceptionThrown)(
            /* [in] */ ObjectID thrownObjectId);
        
	STDMETHOD(ExceptionSearchFunctionEnter)(
            /* [in] */ FunctionID functionId);
        
	STDMETHOD(ExceptionSearchFunctionLeave)(void);
        
	STDMETHOD(ExceptionSearchFilterEnter)(
            /* [in] */ FunctionID functionId);
        
	STDMETHOD(ExceptionSearchFilterLeave)(void);
        
	STDMETHOD(ExceptionSearchCatcherFound)(
            /* [in] */ FunctionID functionId);
        
	STDMETHOD(ExceptionOSHandlerEnter)(
            /* [in] */ UINT_PTR __unused);
        
	STDMETHOD(ExceptionOSHandlerLeave)(
            /* [in] */ UINT_PTR __unused);
        
	STDMETHOD(ExceptionUnwindFunctionEnter)(
            /* [in] */ FunctionID functionId);
        
	STDMETHOD(ExceptionUnwindFunctionLeave)(void);
        
	STDMETHOD(ExceptionUnwindFinallyEnter)(
            /* [in] */ FunctionID functionId);
        
	STDMETHOD(ExceptionUnwindFinallyLeave)(void);
        
	STDMETHOD(ExceptionCatcherEnter)(
            /* [in] */ FunctionID functionId,
            /* [in] */ ObjectID objectId);
        
	STDMETHOD(ExceptionCatcherLeave)(void);
        
	STDMETHOD(COMClassicVTableCreated)(
            /* [in] */ ClassID wrappedClassId,
            /* [in] */ REFGUID implementedIID,
            /* [in] */ void *pVTable,
            /* [in] */ ULONG cSlots);
        
	STDMETHOD(COMClassicVTableDestroyed)(
            /* [in] */ ClassID wrappedClassId,
            /* [in] */ REFGUID implementedIID,
            /* [in] */ void *pVTable);
        
	STDMETHOD(ExceptionCLRCatcherFound)(void);
        
	STDMETHOD(ExceptionCLRCatcherExecute)(void);


	//.........................................................................
    // ICorProfilerInfo2 methods 
	STDMETHOD(ThreadNameChanged)(
            /* [in] */ ThreadID threadId,
            /* [in] */ ULONG cchName,
            /* [in] */ 
            __in_ecount_opt(cchName)  WCHAR name[  ]);
        
	STDMETHOD(GarbageCollectionStarted)(
            /* [in] */ int cGenerations,
            /* [size_is][in] */ BOOL generationCollected[  ],
            /* [in] */ COR_PRF_GC_REASON reason);
        
	STDMETHOD(SurvivingReferences)(
            /* [in] */ ULONG cSurvivingObjectIDRanges,
            /* [size_is][in] */ ObjectID objectIDRangeStart[  ],
            /* [size_is][in] */ ULONG cObjectIDRangeLength[  ]);
        
	STDMETHOD(GarbageCollectionFinished)(void);
        
	STDMETHOD(FinalizeableObjectQueued)(
            /* [in] */ DWORD finalizerFlags,
            /* [in] */ ObjectID objectID);
        
	STDMETHOD(RootReferences2)(
            /* [in] */ ULONG cRootRefs,
            /* [size_is][in] */ ObjectID rootRefIds[  ],
            /* [size_is][in] */ COR_PRF_GC_ROOT_KIND rootKinds[  ],
            /* [size_is][in] */ COR_PRF_GC_ROOT_FLAGS rootFlags[  ],
            /* [size_is][in] */ UINT_PTR rootIds[  ]);
        
	STDMETHOD(HandleCreated)(
            /* [in] */ GCHandleID handleId,
            /* [in] */ ObjectID initialObjectId);
        
	STDMETHOD(HandleDestroyed)(
            /* [in] */ GCHandleID handleId);

};

