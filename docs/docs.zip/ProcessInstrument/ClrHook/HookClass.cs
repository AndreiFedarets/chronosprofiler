﻿using System;
using System.Runtime.InteropServices;

namespace ClrHook
{
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("D9A7CDDF-75EF-4988-9C9D-4FD00A0B9363")]
    [ComVisible(true)]
    public interface ITranpolineInit
    {
        [ComVisible(true)]
        void SetupAppDomain();
    }


    public class TranpolineInit : ITranpolineInit
    {
        public void SetupAppDomain()
        {
            AppDomain.CurrentDomain.AssemblyResolve += DomainAssemblyResolve;
        }

        static System.Reflection.Assembly DomainAssemblyResolve(object sender, ResolveEventArgs args)
        {
            Console.WriteLine("Resolve " + args.Name);
            return args.Name.StartsWith("ClrHook") ? System.Reflection.Assembly.GetExecutingAssembly() : null;
        }
    }

    public class HookClass
    {
        public static void TestHook()
        {
            Console.WriteLine("XX TestHook XX");
        }

    }
}
