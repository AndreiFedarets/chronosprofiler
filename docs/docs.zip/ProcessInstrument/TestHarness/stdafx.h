// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once


//.............................................................................
//> Must be "multi-threaded"
#ifndef  _MT
#error "Multithreading is not activated !"
#endif

//.............................................................................
//> Limt Win32 includes
#define WIN32_LEAN_AND_MEAN	// Supprime les APIs de compatibilit�s Win16
#define NOCOMM				// Pas de gestion d'interface s�rie
#define NOMCX				// Pas de gestion de controle de MODEM

//.............................................................................
//> Force UNICODE
#ifndef		_UNICODE
# define	_UNICODE
#endif //<  _UNICODE

//.............................................................................
//> Force la version 5.2 de Win32 (Win2k3)
#ifdef _WIN32_WINNT
#undef _WIN32_WINNT
#endif
#define _WIN32_WINNT 0x0502

//.............................................................................
//> C++ CRT
#include <stdio.h>
#include <tchar.h>
#include <conio.h>
#include <time.h>
#include <locale.h>
#include <malloc.h>

//.... STL Library ............................................................
#include <exception>
#include <vector>
#include <list>
#include <string>
#include <set>
#include <map>
#include <stack>
#include <limits>
#include <memory>
#include <sstream>
#include <algorithm>

//.............................................................................
//> Win32

#pragma warning(push)
#pragma warning(disable:4995)	//< ('xxxx': name was marked as #pragma deprecated)

//---- Support UNICODE --------------------
#include <tchar.h>

//---- Ent�tes Windows --------------------
#include <windows.h>		// Ent�te universel Windows
#include <Strsafe.h>		// Fonctions de chaine s�curis�s
#include <shellapi.h>		// Shell API			- Used for command line functions
#include <shlwapi.h>		// Utility API			- Used for clean up registry
#include <ole2.h>			// OLE-2 Main Header
#include <olectl.h>			// OLE-2 Control interfaces
#include <objbase.h>		// OLE-2 Base
#include <objidl.h>			// OLE-2 Objects
#include <Shlobj.h>
#include <oleauto.h>

//.............................................................................
#pragma comment(lib,"shell32.lib")	// Platform SDK: Shell 32 API
#pragma comment(lib,"shlwapi.lib")	// Platform SDK: Windows light-weight utility APIs
#pragma comment(lib,"ole32.lib")	// Platform SDK: COM/OLE
#pragma comment(lib,"oleaut32.lib")	// Platform SDK: COM/OLE Automation
#pragma comment(lib,"uuid.lib")		// Platform SDK: MIDL

#pragma warning(pop)

//.... Microsoft VC++ extras ..................................................
#pragma warning(push)
#pragma warning(disable:4995)	//< warning C4995: 'wcscpy': name was marked as #pragma deprecated
#include <comdef.h>			// COM types
#include <atlbase.h>		// ATL base template
#pragma warning(pop)

//.... Microsoft CLR ..........................................................
#include <corerror.h>
#include <corhdr.h>
#include <corprof.h>
#include <Mscoree.h>
#pragma comment(lib,"Mscoree.lib")