// TestHarness.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


extern const CLSID __declspec(selectany) CLSID_LDsCLRProble = { 0x139008cf, 0xed57, 0x49c1, { 0xb8, 0x40, 0x2d, 0xea, 0x89, 0xb6, 0xc7, 0x6c } };

class MiniHostManager : public IHostControl 
{
	LONG m_cRef;
	std::map<DWORD,CComPtr<IUnknown>> m_DomainManagers;
public:
	//.........................................................................
    // Real live constructor
	MiniHostManager() : m_cRef(1) {}
	~MiniHostManager() 
	{ 
		m_DomainManagers.clear();
	}

	//.........................................................................
    // IUnknown methods 
    STDMETHOD(QueryInterface) (REFIID riid, LPVOID FAR* ppvObj)
	{
		*ppvObj = NULL;
	    
		if (riid == IID_IUnknown || riid == IID_IHostControl)
		{
			*ppvObj = this;
			AddRef();
			return S_OK;    
		}

		return E_NOINTERFACE; 
	}

    STDMETHOD_(ULONG, AddRef) (void)
	{
		return InterlockedIncrement(&m_cRef);
	}
    STDMETHOD_(ULONG, Release)(void)
	{   
		LONG cRef;
		cRef=InterlockedDecrement(&m_cRef);
		if(cRef == 0)
		{
			delete this;
			return 0;
		}
		return cRef;
	}    
	//.........................................................................
    STDMETHOD(GetHostManager) (REFIID riid,void **ppvObj)
	{
		if(riid==__uuidof(IAppDomainBinding)) puts("HI");
		*ppvObj =NULL;
		return S_OK; 
	}

    STDMETHOD(SetAppDomainManager) (DWORD dwAppDomainID, IUnknown* pUnkAppDomainManager)
	{
		m_DomainManagers[dwAppDomainID] = pUnkAppDomainManager;
		return S_OK; 
	}
};



int _tmain(int argc, _TCHAR* argv[])
{
	// Define the profiler
	BOOL r;
	r =SetEnvironmentVariable(L"COR_ENABLE_PROFILING",	L"1");
	r =SetEnvironmentVariable(L"COR_PROFILER",			L"{139008CF-ED57-49c1-B840-2DEA89B6C76C}");

	


	CComPtr<IUnknown> testPtr;
	HRESULT hr =  CoInitializeEx(0, COINIT_MULTITHREADED); 
	//hr= testPtr.CoCreateInstance(CLSID_LDsCLRProble);

	
	CComPtr<ICLRRuntimeHost> rtHost;
	hr= CorBindToRuntimeEx(
			L"v2.0.50727",NULL,
			0,				//< Pas de flag (defaut)
			CLSID_CLRRuntimeHost,IID_ICLRRuntimeHost,(LPVOID*)&rtHost);

	CComPtr<ICLRControl> rtControl;
	hr = rtHost->GetCLRControl(&rtControl);

	CComPtr<IHostControl> manager = new MiniHostManager();
	hr = rtHost->SetHostControl(manager);

	hr = rtHost->Start();

	DWORD appDom;
	hr = rtHost->GetCurrentAppDomainId(&appDom);


	DWORD retVal;
	hr = rtHost->ExecuteInDefaultAppDomain(
			L"..\\..\\TestApplication\\Bin\\Debug\\TestApplication.exe",
			L"TestApplication.Program",
			L"Go",L"",
			&retVal);
	

	return 0;
}

